﻿<#
    .Synopsis        
        Script to Sync a specific Term Set
    .Notes
        Name: SyncSpecificTermSet.ps1
        Sources: 
        Author: Brent Person, Microsoft, brpers@microsoft.com
        Last Edit: 07/10/2019
#>

#region Global Variables
# Change the following to fit your SPO and OnPrem environments
Set-Location -Path 'D:\Scripts\SyncTermStore' # Physical path to where the scripts are located
$srcSite = "https://www.Contoso.com" # OnPrem Site url for Context
$srcIsSharePointOnline = $false # specifies if the srcSite is OnPrem or Online
$destSite = "https://tenant.sharepoint.com" # SPO Site url for Context
$destIsSharePointOnline = $true # specifies if the destSite is OnPrem or Online
$srcSsTargetAppId = "OnPrem" # Secure Store App Id for Src Site
$destSsTargetAppId = "SPO" # Secure Store App Id for Dest Site
$ssSite = "https://www.Contoso.com" # Secure Store Site for context - usually this in a OnPrem Site
$rootLogFolder = "D:\Scripts\SyncTermStore\Logs" # Log location
$logRetentionHours = 48 # how many hours you want to keep the logs for
$termGroupName = "Term Group" # Term Group Name you'd like to sync
$Termsetname = "Term Set" # Term Set Name you'd like to sync
$scriptPath = (Get-Location -PSProvider FileSystem).ProviderPath
$VerbosePreference = "Continue"

$global:LogPath=(Get-Item -Path ".\").FullName 
$global:LogName = "script.log"
$global:LogFile = Join-Path -Path $LogPath -ChildPath $LogName
$global:UPN = "@Contoso.com"
$global:Domain = "Contoso\"

# Add references to SharePoint client assemblies - required for CSOM
# Change if your installation directory is not default
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Taxonomy.dll"

#This code calls to a Microsoft web endpoint to track how often it is used. 
#No data is sent on this call other than the application identifier
Add-Type -AssemblyName System.Net.Http
$client = New-Object -TypeName System.Net.Http.Httpclient
$cont = New-Object -TypeName System.Net.Http.StringContent("", [system.text.encoding]::UTF8, "application/json")
$tsk = $client.PostAsync("https://msapptracker.azurewebsites.net/api/Hits/88ef393f-ada7-4607-9be2-b5175dcb3577",$cont)
#endregion

# CHANGE NOTHING BELOW THIS LINE
############################################

# load helper scripts
. .\Syncfunctions.ps1
. .\CSOMHelper.ps1
. .\PSJobHelper.ps1
. .\SecureStoreServiceHelper.ps1

$startTime = Get-Date
$logFolder = Get-LogFolderWithDate -scriptPath $rootLogFolder -date $startTime
$logFolder = $logFolder.FullName
Write-Verbose "Log folder: ""$logFolder"""

# Start a transcript
Start-TranscriptHelper -scriptName "SyncTermGroup_$termGroupName" -logFolder $logFolder

Write-Verbose "Parameters:"
Write-Verbose "`ttermGroupName = $termGroupName"
Write-Verbose "`tTermSet = $Termsetname"
Write-Verbose "`tsrcSite = $srcSite"
Write-Verbose "`tdestSite = $destSite"
Write-Verbose "`tsrcUser = $srcUser"
Write-Verbose "`tsrcPassword = ***"
Write-Verbose "`tsrcSsTargetAppId = $srcSsTargetAppId"
Write-Verbose "`tsrcIsSharePointOnline = $srcIsSharePointOnline = $false"
Write-Verbose "`tdestUser = $destUser"
Write-Verbose "`tdestPassword = ***"
Write-Verbose "`tdestSsTargetAppId = $destSsTargetAppId"
Write-Verbose "`tdestIsSharePointOnline $destIsSharePointOnline"
Write-Verbose "`tssSite = $ssSite"
Write-Verbose "`tmaxThreads = $maxThreads"
Write-Verbose "`trootLogFolder = $rootLogFolder"
Write-Verbose "`tlogRetentionHours = $logRetentionHours"
Write-Verbose ""

#region Body

# Wrap in a Try so that we can make sure the context objects are exposed of
try
{
	#region Get Context
    Write-Verbose "Getting the source connection - $(Get-Date)"
    $srcContext = Get-SPClientConnection -site $srcSite -isSharePointOnline $srcIsSharePointOnline -user $srcUser -password $srcPassword -sssSite $ssSite -sssTargetAppId $srcSsTargetAppId -requestTimeoutSec 300

    Write-Verbose "Getting the destination connection - $(Get-Date)"
    $destContext = Get-SPClientConnection -site $destSite -isSharePointOnline $destIsSharePointOnline -user $destUser -password $destPassword -sssSite $ssSite -sssTargetAppId $destSsTargetAppId -requestTimeoutSec 300


    # If we're given a target app id then we need to pull out the password from the target app
    if( ![string]::IsNullOrEmpty($srcSsTargetAppId) )
    {
        Write-Verbose "Getting the source connection password - $(Get-Date)"
        $srcSSCred = Get-CredentialsFromSecureStore -contextSiteUrl $ssSite -ssTargetAppName $srcSsTargetAppId
        $srcPassword = ConvertTo-SecureString -AsPlainText (Get-ValueFromSecureStoreCredentials -ssCredentials $srcSSCred -ssCredentialType Password) -Force
        $srcUser = Get-ValueFromSecureStoreCredentials -ssCredentials $srcSSCred -ssCredentialType User
        
    }

    if( ![string]::IsNullOrEmpty($destSsTargetAppId) )
    {
        Write-Verbose "Getting the destination connection password - $(Get-Date)"
        $destSSCred = Get-CredentialsFromSecureStore -contextSiteUrl $ssSite -ssTargetAppName $destSsTargetAppId
        $destUser = Get-ValueFromSecureStoreCredentials -ssCredentials $destSSCred -ssCredentialType User
        $destPassword = ConvertTo-SecureString -AsPlainText (Get-ValueFromSecureStoreCredentials -ssCredentials $destSSCred -ssCredentialType Password) -Force
    }
    #endregion

	#region Get Taxonomy Session and Stores
    # Kick off the sync process for the term group
    Write-Verbose "Starting sync of term group $termGroupName - $(Get-Date)"
    Write-Debug "$($MyInvocation.MyCommand.Name): Begin"
    Write-Verbose "$($MyInvocation.MyCommand.Name): Starting. Will sync term $termGroupName from $srcSite to $destSite."

    # Make sure that all of the critical initial steps are successful.
    $ErrorActionPreference = "Stop"

    
	# Create our taxonomy session on the Source site
    Write-Verbose "$($MyInvocation.MyCommand.Name): Establishing taxonomy session with $($srcContext.Url)"
    $srcTaxonomySession = [Microsoft.SharePoint.Client.Taxonomy.TaxonomySession]::GetTaxonomySession($srcContext)
    Load-CSOMObject -context $srccontext -object ([REF]$srcTaxonomySession) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false

	# Create our taxonomy session on the Destination site
    Write-Verbose "$($MyInvocation.MyCommand.Name): Establishing taxonomy session with $($destContext.Url)"
    $destTaxonomySession = [Microsoft.SharePoint.Client.Taxonomy.TaxonomySession]::GetTaxonomySession($destContext)
    Load-CSOMObject -context $destcontext -object ([REF]$destTaxonomySession) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false

	# Get the source term stores
    Write-Verbose "$($MyInvocation.MyCommand.Name): Getting the source term stores"
    [Microsoft.SharePoint.Client.Taxonomy.TermStoreCollection]$srcTermStores = $srcTaxonomySession.TermStores
    Load-CSOMObject -context $srcContext -object ([REF]$srcTermStores) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false

    # Get the destination term stores
    Write-Verbose "$($MyInvocation.MyCommand.Name): Getting the destination term stores"
    [Microsoft.SharePoint.Client.Taxonomy.TermStoreCollection]$destTermStores = $destTaxonomySession.TermStores
    Load-CSOMObject -context $destContext -object ([REF]$destTermStores) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false
    
    #Start-Sleep 2

    # Get the first source term store
    Write-Verbose "$($MyInvocation.MyCommand.Name): Getting the first source term store"
    [Microsoft.SharePoint.Client.Taxonomy.TermStore]$srcTermStore = $srcTermStores[0]
    Load-CSOMObject -context $srcContext -object ([REF]$srcTermStore) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false

	# set LCID to termstore default language
	[Int32]$Lcid = $srcTermStore.DefaultLanguage

	# Get the first destination term store
    Write-Verbose "$($MyInvocation.MyCommand.Name): Getting the first destination term store"
    [Microsoft.SharePoint.Client.Taxonomy.TermStore]$destTermStore = $destTermStores[0]
    Load-CSOMObject -context $destContext -object ([REF]$destTermStore) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false
	#endregion

	#region TermGroups
    # Get the source term groups
    Write-Verbose "$($MyInvocation.MyCommand.Name): Getting the source term groups"
    [Microsoft.SharePoint.Client.Taxonomy.TermGroupCollection]$srcTermGroups = $srcTermStore.Groups
    Load-CSOMObject -context $srcContext -object ([REF]$srcTermGroups) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false

	# Get the Destination term groups
    Write-Verbose "$($MyInvocation.MyCommand.Name): Getting the Remote term groups"
    [Microsoft.SharePoint.Client.Taxonomy.TermGroupCollection]$destTermGroups = $destTermStore.Groups
    Load-CSOMObject -context $destContext -object ([REF]$destTermGroups) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false

	# Get the specific Source Term Group
	Write-Verbose "$($MyInvocation.MyCommand.Name): Getting the Source term group ""$($termGroupName)"""
	[Microsoft.SharePoint.Client.Taxonomy.TermGroup]$srcTermGroup = $srcTermGroups | ? {$_.Name -eq "$($termGroupName)"}
	Load-CSOMObject -context $srcContext -object ([REF]$srcTermGroup) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false
	$srcTermGroupId = $srcTermGroup.Id
    
    # Get the Source Term Sets
	[Microsoft.SharePoint.Client.Taxonomy.TermSetCollection]$srcTermSets = $srcTermGroup.TermSets
	Load-CSOMObject -context $srcContext -object ([REF]$srcTermSets) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false
	
    # Get the Source Term Set Specified
	[Microsoft.SharePoint.Client.Taxonomy.TermSet]$TermSet = $srcTermSets | ?{$_.Name -eq "$Termsetname"}
	Load-CSOMObject -context $srcContext -object ([REF]$TermSet) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false

	# Get the specific Destination Term Group
    if($destTermGroups.Name -notcontains $termGroupName)
    {
		Write-Verbose "$($MyInvocation.MyCommand.Name): Term group '$termGroupName' does not exist at the destination. Creating it."
        $destTermGroup = $destTermStore.CreateGroup($termGroupName, $srcTermGroupId)
        Load-CSOMObject -context $destContext -object ([REF]$destTermGroup) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false

		# Commit all of the changes thus far to the term store to avoid conflicts
        $destTermStore.CommitAll()
		$destTermStore.UpdateCache()
        Start-Sleep 2

		# Get the newly created Term Group in Destination
		[Microsoft.SharePoint.Client.Taxonomy.TermGroup]$destTermGroup = $destTermGroups.GetByName($termGroupName)
		Load-CSOMObject -context $destContext -object ([REF]$destTermGroup) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false
	    
    }
	else
	{
		Write-Verbose "$($MyInvocation.MyCommand.Name): Term group '$termGroupName' already exists at the destination."
		Write-Verbose "$($MyInvocation.MyCommand.Name): Getting the Destination term group ""$($termGroupName)"""
	    [Microsoft.SharePoint.Client.Taxonomy.TermGroup]$destTermGroup = $destTermGroups | ? {$_.Name -eq "$($termGroupName)"}
	    Load-CSOMObject -context $destContext -object ([REF]$destTermGroup) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false
	}
	
	# Create Destination Term Group if it does not already exist
	If(!($destTermGroup.ServerObjectIsNull) -or !([string]::IsNullOrEmpty($destTermGroup.Name)))
	{	
		Write-Verbose "$($MyInvocation.MyCommand.Name): Syncing Term Group: ""$termGroupName""."	
		SyncTermGroupInfo -destContext $destContext -srcContext $srcContext -destTermGroup $destTermGroup -srcTermGroup $srcTermGroup 
	}
	Else
	{
		Write-Verbose "$($MyInvocation.MyCommand.Name): There was a problem getting the Destination Term Group: ""$termGroupName""."
		break
	}

	[Microsoft.SharePoint.Client.Taxonomy.TermSetCollection]$destTermSets = $destTermGroup.termsets
	Load-CSOMObject -context $destContext -object ([REF]$destTermSets) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false
	#endregion

	#region TermSets
        [Microsoft.SharePoint.Client.Taxonomy.Termcollection]$TermSetTerms = $Termset.Terms
        Load-CSOMObject -context $srcContext -object ([REF]$TermSetTerms) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false
		$TsId = $termset.Id.ToString()
        Write-Verbose "$($MyInvocation.MyCommand.Name): ""$Termsetname"" ""$TsId"""

		If($Termsetname -notin $destTermSets.Name)
		{
			#create TermSet
			[Microsoft.SharePoint.Client.Taxonomy.TermSet]$DestTermSet = $destTermGroup.CreateTermSet($Termsetname, $TsId, $Lcid)
            $destTermStore.CommitAll()
			$destTermStore.UpdateCache()
			Start-Sleep -Seconds 2

			Load-CSOMObject -context $destContext -object ([REF]$DestTermSet) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false
			SyncTermSetInfo -destContext $destContext -srcContext $srcContext -srcTermSet $Termset -destTermSet $DestTermSet

			[Microsoft.SharePoint.Client.Taxonomy.TermCollection]$destTerms = $destTermSet.Terms
			Load-CSOMObject -context $destContext -object ([REF]$destTerms) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false
		}
		else
		{
			#get the existing destination termset
			[Microsoft.SharePoint.Client.Taxonomy.Termset]$destTermSet = $destTermSets | ? {$_.Name -eq $Termsetname}
			Load-CSOMObject -context $destContext -object ([REF]$destTermSet) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false
			SyncTermSetInfo -destContext $destContext -srcContext $srcContext -srcTermSet $Termset -destTermSet $destTermSet
		}
	#endregion
	#region Terms
	$parent = $DestTermSet
		If($TermSetTerms.Count -gt 0)
		{
            foreach($srcTerm in $TermSetTerms)
            {
                Load-CSOMObject -context $srcContext -object ([REF]$srcTerm) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false
				
				WalkTerm -srcTerm $srcTerm -destTermSet $destTermSet -srcContext $srcContext -destContext $destContext -parent $destTermSet
			}
		}
	
	#endregion

Write-Verbose "$($MyInvocation.MyCommand.Name): FIN."
}
finally
{
    if($srcContext -ne $null) 
    { 
        $srcContext.Dispose() 
        $srcContext = $Null 
    }
    if($destContext -ne $null) 
    { 
        $destContext.Dispose() 
        $destContext = $Null
    }
}

Stop-TranscriptHelper

# Perform log cleanup
if ($logRetentionHours -gt 0)
{
    Write-Verbose "Cleaning up logs greater than $logRetentionHours hours old"

    Get-ChildItem -Path $rootLogFolder -Directory:$true | Where-Object {$_.CreationTime -le ((Get-Date).AddHours($logRetentionHours * -1))} | Remove-Item -Confirm:$false -Recurse:$true

    Write-Verbose "`tDone"
}
#endregion