﻿<#
    .Synopsis        
        Script to output all the Reused and Pinned terms where the term is not a source term to csv file from SharePoint OnPrem.
		This would have to be adjusted for SPO as this is not written in CSOM.
    .Notes
        Name: DocumentPinnedReusedTerms.ps1
        Sources: 
        Author: Brent Person, Microsoft, brpers@microsoft.com
        Last Edit: 07/11/2019
#>

# Change the following to fit your environment
$SrcSiteUrl = "https://www.contoso.com" #Myteamsstage
$outputFilePath = "D:\script\TermStore\Output\"
$TermStoreName = "TermStore"

Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Taxonomy.dll"

# Change nothing below this line
############################################

# This code calls to a Microsoft web endpoint to track how often this script it is used. 
# No data is sent on this call other than the application identifier
Add-Type -AssemblyName System.Net.Http
$client = New-Object -TypeName System.Net.Http.Httpclient
$cont = New-Object -TypeName System.Net.Http.StringContent("", [system.text.encoding]::UTF8, "application/json")
$tsk = $client.PostAsync("https://msapptracker.azurewebsites.net/api/Hits/636cca88-d752-4148-b8db-a91bee574cff",$cont)


$SrctaxonomySite = Get-SPSite -Identity $SrcSiteUrl
$SrctaxonomySession = Get-SPTaxonomySession -site $SrctaxonomySite
$SrctaxonomySession.UpdateCache()
$SrctaxonomyTermStore =  $SrctaxonomySession.TermStores
$SrctermStore = $SrctaxonomySession.TermStores["$TermStoreName"]
$groups = $Srctermstore.Groups
foreach($Group in $groups)
{
    $outputFileNamePinned = "$($Group.Name) Pinned.csv"
    $outputFileNameReused = "$($Group.Name) Reused.csv"
    $termsets = $group.TermSets
    $CSVDataPinnedTerms = @();
    $CSVDataReusedTerms = @();
    foreach($termset in $termsets)
    {
        $terms = $termset.GetAllTerms()
        foreach($term in $terms)
        {
            If($term.IsPinned)
            {
                $CSVDataPinnedTerms += [PSCustomObject][Ordered]@{
                TermSetName = "$($term.termset.name)"
                TermSetID = "$($term.termset.Id)"
                TermName = "$($term.Name)"
                TermID = "$($term.Id)"
                TermParentID = "$($Term.Parent.Id)"
                TermParentName = "$($term.Parent.Name)"
                SourceTermSetName = "$($term.SourceTerm.TermSet.Name)"
                SourceTermSetID = "$($term.SourceTerm.TermSet.Id)"
                SourceGroupName = "$($Term.SourceTerm.TermSet.Group.Name)"} | Export-CSV "$($outputFilePath)$($outputFileNamePinned)" -Append -NoTypeInformation
            }
            ElseIf(($term.IsReused) -and (!($term.IsSourceTerm)))
            {
                $CSVDataReusedTerms += [PSCustomObject][Ordered]@{
                TermSetName = "$($term.termset.name)"
                TermSetID = "$($term.termset.Id)"
                TermName = "$($term.Name)"
                TermID = "$($term.Id)"
                TermIsRoot = "$($term.isRoot.ToString())"
                TermParentID = "$($Term.Parent.Id)"
                TermParentName = "$($term.Parent.Name)"
                SourceTermSetName = "$($term.SourceTerm.TermSet.Name)"
                SourceTermSetID = "$($term.SourceTerm.TermSet.Id)"
                SourceGroupName = "$($Term.sourceterm.termset.group.Name)"} | Export-CSV "$($outputFilePath)$($outputFileNameReused)" -Append -NoTypeInformation;
            }        
        }
    }
}
