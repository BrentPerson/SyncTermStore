﻿<#
    .Synopsis        
        Validation script to find missing/extra terms in specified Term Group/Term Set
    .Notes
        Name: FindMissingTermsInTermSet.ps1
        Sources: 
        Author: Brent Person, Microsoft, brpers@microsoft.com
        Last Edit: 07/10/2019
#>

#This code calls to a Microsoft web endpoint to track how often it is used. 
#No data is sent on this call other than the application identifier
Add-Type -AssemblyName System.Net.Http
$client = New-Object -TypeName System.Net.Http.Httpclient
$cont = New-Object -TypeName System.Net.Http.StringContent("", [system.text.encoding]::UTF8, "application/json")
$tsk = $client.PostAsync("https://msapptracker.azurewebsites.net/api/Hits/c4261174-e42b-4311-889e-46a08493cc01",$cont)

# Change the following to fit your OnPrem and SPO environments
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Taxonomy.dll"

# Term Group and Term Set Name
$TermGroupName = "Term Group"
$TermSetName = "Term Set"

# On Prem
$SPSite = "https://sptest.campperson.com" # On-Prem Site for context
$SPUsername = "domain\username" # Term Store Admin
$SPPassword = "Password"

# SPO
$SPOSite = "https://tenant.sharepoint.com" # SPO Site for context
$SPOUsername = "TermStoreAdmin@tenant.onmicrosoft.com" # SPO Term Store Admin
$SPOPassword = "Password"

#region OnPrem
$SPSecurePassword = Convertto-SecureString –String $SPPassword –AsPlainText –force
$SPCredentials = New-object System.Management.Automation.PSCredential $SPUsername,$SPSecurePassword
[Microsoft.SharePoint.Client.ClientContext]$SPContext = New-Object Microsoft.SharePoint.Client.ClientContext($SPSite)
$SPContext.Credentials = $SPCredentials
$SPMMS = [Microsoft.SharePoint.Client.Taxonomy.TaxonomySession]::GetTaxonomySession($SPContext)
$SPContext.Load($SPMMS)
$SPContext.ExecuteQuery()
$SPContext.Load($SPMMS.TermStores)
$SPContext.ExecuteQuery()
$SPtermstore = $SPMMS.TermStores | ?{$_.Name -eq "TylerMMD"}
$SPContext.Load($SPtermstore)
$SPContext.ExecuteQuery()
$SPContext.Load($SPTermStore.Groups)
$SPContext.ExecuteQuery()

$SPGroup = $SPtermstore.Groups | ?{$_.Name -eq "$TermGroupName"}
$SPContext.Load($SPGroup)
$SPContext.ExecuteQuery()
Write-Host "$($SpGroup.Name)" -ForegroundColor Green;

$SPContext.Load($SPGroup.TermSets)
$SPContext.ExecuteQuery()

$SPTermSet = $SPGroup.TermSets | ?{$_.Name -eq "$TermSetName"}
$SPContext.Load($SPTermSet)
$SPContext.ExecuteQuery()
$SPTermSet.Name

$SPAllTerms = $SPTermSet.GetAllTerms()
$SPContext.Load($SPAllTerms)
$SPContext.ExecuteQuery()

$SPids = $SPAllTerms.id 
#endregion

#region SPO
$SPOSecurePassword = ConvertTo-SecureString -String $SPOPassword -AsPlainText -Force
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Taxonomy.dll"
[Microsoft.SharePoint.Client.ClientContext]$SPOContext = New-Object Microsoft.SharePoint.Client.ClientContext($SPOSite)
$Creds = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($SPOUsername, $SPOSecurePassword)
$SPOContext.Credentials = $Creds
$MMS = [Microsoft.SharePoint.Client.Taxonomy.TaxonomySession]::GetTaxonomySession($SPOContext)
$SPOContext.Load($MMS)
$SPOContext.ExecuteQuery()
$SPOContext.Load($MMS.TermStores)
$SPOContext.ExecuteQuery()
$termstore = $mms.TermStores[0]
$SPOContext.Load($termstore)
$SPOContext.ExecuteQuery()
$SPOContext.Load($TermStore.Groups)
$SPOContext.ExecuteQuery()

$Group = $termstore.Groups | ?{$_.Name -eq "$TermGroupName"}
$SPOContext.Load($Group)
$SPOContext.ExecuteQuery()
Write-Host "$($Group.Name)" -ForegroundColor Green;

$SPOContext.Load($Group.TermSets)
$SPOContext.ExecuteQuery()

$TermSet = $Group.TermSets | ?{$_.Name -eq "$TermSetName"}
$SPOContext.Load($TermSet)
$SPOContext.ExecuteQuery()
$TermSet.Name

$AllTerms = $TermSet.GetAllTerms()
$SPOContext.Load($AllTerms)
$SPOContext.ExecuteQuery()

$ids = $AllTerms.id 
#endregion 

#region Find Missing Terms in SPO
#uncomment to find the missing terms in SPO
<#
#region missing ids in SPO
$missingids = $SPids | ?{$_ -notin $ids}
foreach($missing in $missingids)
{
    $term = $SPtermset.GetTerm("$missing")
    $spcontext.Load($term)
    $spcontext.ExecuteQuery()
    Write-Host "$($Term.PathOfTerm)" -ForegroundColor Green
}
#>
#endregion

#region Find Extra Terms in SPO
#uncomment to find extra terms in SPO
<#
#region extra ids in SPO
$missingids = $ids | ?{$_ -notin $SPids}
foreach($missing in $missingids)
{
    $term = $termset.GetTerm("$missing")
    $SPOContext.Load($term)
    $SPOContext.ExecuteQuery()
    Write-Host "$($Term.PathOfTerm)" -ForegroundColor Green
}
#>
#endregion