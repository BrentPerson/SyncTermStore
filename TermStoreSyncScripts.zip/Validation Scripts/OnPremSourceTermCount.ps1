﻿<#
    .Synopsis        
        Validation script to get a count of terms per term set per term group for SharePoint On-Premises
    .Notes
        Name: FindMissingTermsInTermSet.ps1
        Sources: 
        Author: Brent Person, Microsoft, brpers@microsoft.com
        Last Edit: 07/10/2019
#>

# This code calls to a Microsoft web endpoint to track how often it is used. 
# No data is sent on this call other than the application identifier
Add-Type -AssemblyName System.Net.Http
$client = New-Object -TypeName System.Net.Http.Httpclient
$cont = New-Object -TypeName System.Net.Http.StringContent("", [system.text.encoding]::UTF8, "application/json")
$tsk = $client.PostAsync("https://msapptracker.azurewebsites.net/api/Hits/cb561ea6-ddb7-4e26-911d-f6927dd116c4",$cont)

# Change the following to fit your environment
$spsite = "https://www.contoso.com" # OnPrem Site for Context
$Username = "domain\username" # Term Store Admin 
$Password = "Password"
$TermStoreName = "Term Store"
$filePath = "D:\script\TermStore\OnPremTermCount.csv" # Output file path for csv file

Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Taxonomy.dll"

# CHANGE NOTHING BELOW THIS LINE
############################################

$SecurePassword = Convertto-SecureString –String $Password –AsPlainText –force
$SPCredentials = New-object System.Management.Automation.PSCredential $Username,$SecurePassword
[Microsoft.SharePoint.Client.ClientContext]$SPContext = New-Object Microsoft.SharePoint.Client.ClientContext($SPSite)
$SPContext.Credentials = $SPCredentials
$SPMMS = [Microsoft.SharePoint.Client.Taxonomy.TaxonomySession]::GetTaxonomySession($SPContext)
$SPContext.Load($SPMMS)
$SPContext.ExecuteQuery()
$SPContext.Load($SPMMS.TermStores)
$SPContext.ExecuteQuery()
$SPtermstore = $SPMMS.TermStores | ?{$_.Name -eq "$TermStoreName"}
$SPContext.Load($SPtermstore)
$SPContext.ExecuteQuery()
$SPContext.Load($SPTermStore.Groups)
$SPContext.ExecuteQuery()

foreach($SPGroup in $SPTermStore.Groups)
{
    $SPContext.Load($SPGroup)
    $SPContext.ExecuteQuery()
    Write-Host "$($SpGroup.Name)" -ForegroundColor Green;
    $SPContext.Load($SPGroup.TermSets)
    $SPContext.ExecuteQuery()

    Foreach($termset in $SPGroup.TermSets)
    {
        $SPContext.Load($termset)
        $SPContext.ExecuteQuery()
        $terms = $termset.GetAllTerms()
        $SPContext.Load($terms)
        $SPContext.ExecuteQuery()
        Write-Host $Termset.Name -ForegroundColor Red
        Write-Host $terms.count -ForegroundColor Yellow

	    $CSVData += [PSCustomObject][Ordered]@{
            TermGroup = "$($SPGroup.Name)"
            TermSetName = "$($Termset.Name)"
            TermCount = "$($terms.count)"} | Export-CSV "$filePath" -Append -NoTypeInformation;
    }
}