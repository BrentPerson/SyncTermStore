﻿<#
    .Synopsis        
        Validation script to get a count of terms per term set per term group from SharePoint Online
    .Notes
        Name: SPOSourceTermCount.ps1
        Sources: 
        Author: Brent Person, Microsoft, brpers@microsoft.com
        Last Edit: 07/10/2019
#>

#This code calls to a Microsoft web endpoint to track how often it is used. 
#No data is sent on this call other than the application identifier
Add-Type -AssemblyName System.Net.Http
$client = New-Object -TypeName System.Net.Http.Httpclient
$cont = New-Object -TypeName System.Net.Http.StringContent("", [system.text.encoding]::UTF8, "application/json")
$tsk = $client.PostAsync("https://msapptracker.azurewebsites.net/api/Hits/160f3ec9-9825-42c8-8e66-eb28a6584515",$cont)

# Change the following to fit your environment
$SPOSite = "https://Tenant.onmicrosoft.com"; # SPO Site for context
$Username = "User@Tenant.onmicrosoft.com"; # SPO Term Store Admin
$password = "PASSWORD";
$filePath = "D:\script\TermStore\SPOTermCount.csv" # Output file path for csv file

# Change nothing Below this line
#########################################
$SecurePassword = ConvertTo-SecureString -String $Password -AsPlainText -Force
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Taxonomy.dll"
[Microsoft.SharePoint.Client.ClientContext]$Context = New-Object Microsoft.SharePoint.Client.ClientContext($SPOSite)
$Creds = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($Username, $SecurePassword)
$Context.Credentials = $Creds
$MMS = [Microsoft.SharePoint.Client.Taxonomy.TaxonomySession]::GetTaxonomySession($Context)
$Context.Load($MMS)
$Context.ExecuteQuery()
$Context.Load($MMS.TermStores)
$Context.ExecuteQuery()
$termstore = $mms.TermStores[0]
$Context.Load($termstore)
$Context.ExecuteQuery()
$Context.Load($TermStore.Groups)
$Context.ExecuteQuery()

foreach($Group in $TermStore.Groups)
{
    $Context.Load($Group)
    $Context.ExecuteQuery()
    Write-Host "$($Group.Name)" -ForegroundColor Green;
    $Context.Load($Group.TermSets)
    $Context.ExecuteQuery()

    Foreach($termset in $Group.TermSets)
    {
        $Context.Load($termset)
        $Context.ExecuteQuery()
        $terms = $termset.GetAllTerms()
        $Context.Load($terms)
        $Context.ExecuteQuery()
        Write-Host $Termset.Name -ForegroundColor Red
        Write-Host $terms.count -ForegroundColor Yellow

	    $CSVData += [PSCustomObject][Ordered]@{
            TermCount = "$($terms.count)"
            TermGroup = "$($Group.Name)"
            TermSetName = "$($Termset.Name)"} | Export-CSV "$filePath" -Append -NoTypeInformation;
    }
}