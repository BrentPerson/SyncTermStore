﻿<#
    .Synopsis        
        Holds various functions for working with the Secure Store Service
    .Notes
        Name: SecureStoreServiceHelper.ps1
        Sources: http://msdn.microsoft.com/en-us/library/office/ff394459(v=office.14).aspx
        Author: Brian Laws, Summit 7 Systems
        Last Edit: 4/29/2014
#>

#region Load prerequisites
Write-Debug "$($MyInvocation.MyCommand.Name): Loading required assemblies"
if((Get-PSSnapin Microsoft.SharePoint.Powershell -ErrorAction SilentlyContinue) -eq $null) { Add-PSSnapin Microsoft.SharePoint.PowerShell; $Error.Clear() }

# Add references to SharePoint assemblies we'll be using
# Change if your installation directory is not default
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.Office.SecureStoreService.Server.Security.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.BusinessData.dll"
#endregion

function Get-SecureStoreProvider
{
<#
    .Synopsis        
        Get a [Microsoft.BusinessData.Infrastructure.SecureStore.ISecureStoreProvider] object for the given on-premises site
    .Parameter $contextSiteUrl
        The URL of the on-premises site connected to the Secure store Service
    .Example
        $ssp = Get-SecureStoreProvider -contextSiteUrl $contextSiteUrl
    .Outputs
        [Microsoft.BusinessData.Infrastructure.SecureStore.ISecureStoreProvider] of the secure store provider
    .Notes
        Name: Get-SecureStoreProvider
        Sources: 
        Author: Brian Laws, Summit 7 Systems
        Last Edit: 4/29/2014
#>
    [CmdletBinding()]
    Param 
    (
        [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$contextSiteUrl
    )
    $ErrorActionPreference = "Stop"
    Write-Debug "$($MyInvocation.MyCommand.Name): Begin"

    [Microsoft.BusinessData.Infrastructure.SecureStore.ISecureStoreProvider]$ssp = New-Object Microsoft.Office.SecureStoreService.Server.SecureStoreProvider

    Write-Verbose "$($MyInvocation.MyCommand.Name): Getting the service context for site $contextSiteUrl"
    $spContext = Get-SPServiceContext -Site $contextSiteUrl -Verbose:$false

    Write-Verbose "$($MyInvocation.MyCommand.Name): Getting the Secure Store provider and setting context"
    $ssp.Context = $spContext

    Write-Debug "$($MyInvocation.MyCommand.Name): End"
    return $ssp
}

function Get-CredentialsFromSecureStore
{
<#
    .Synopsis        
        Gets a [Microsoft.BusinessData.Infrastructure.SecureStore.SecureStoreCredentialCollection] object containing the credentials stored in a Secure Store Service Target Application
    .Parameter contextSiteUrl
        The URL of the on-premises site connected to the Secure store Service
    .Parameter ssTargetAppName
        The Secure Store Service target application ID/name containing the credentials to retrieve
    .Outputs
        [Microsoft.BusinessData.Infrastructure.SecureStore.SecureStoreCredentialCollection] containing the stored credentials 
    .Example
        $ssCreds = Get-CredentialsFromSecureStore -contextSiteUrl "http://onpremises" -ssTargetAppName "Some Target App Name"
    .Notes
        Name: Get-CredentialsFromSecureStore
        Sources: 
        Author: Brian Laws, Summit 7 Systems
        Last Edit: 4/29/2014
#>
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$contextSiteUrl,
        [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$ssTargetAppName
    )
    $ErrorActionPreference = "Stop"
    Write-Debug "$($MyInvocation.MyCommand.Name): Begin"

    Write-Verbose "$($MyInvocation.MyCommand.Name): Getting the Secure Store Provider from ""$contextSiteUrl"""
    $ssp = Get-SecureStoreProvider -contextSiteUrl $contextSiteUrl

    Write-Verbose "$($MyInvocation.MyCommand.Name): Getting the Credentials for Secure Store Target Application ""$ssTargetAppName"""
    [Microsoft.BusinessData.Infrastructure.SecureStore.SecureStoreCredentialCollection]$ssCreds = $ssp.GetCredentials($ssTargetAppName)

    Write-Debug "$($MyInvocation.MyCommand.Name): End"
    return $ssCreds
}

function Convert-SecureStringToString
{
<#
    .Synopsis        
        Convert a SecureString object into a standard string
    .Parameter secureString
        SecureString object to convert
    .Outputs
        String containing the converted text
    .Example
        $password = Convert-SecureStringToString -secureString (ConvertTo-SecureString "password" –AsPlainText –Force)
    .Notes
        Name: Convert-SecureStringToString
        Sources: 
        Author: Brian Laws, Summit 7 Systems
        Last Edit: 4/29/2014
#>
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true)][System.Security.SecureString]$secureString
    )
    Write-Debug "$($MyInvocation.MyCommand.Name): Begin"

    $plainString = [Runtime.InteropServices.Marshal]::PtrToStringBSTR([Runtime.InteropServices.Marshal]::SecureStringToBSTR($secureString))

    Write-Debug "$($MyInvocation.MyCommand.Name): End"
    return $plainString
}

function Get-ClientCredentialFromSecureStore
{
<#
    .Synopsis        
        Retruns a [Microsoft.SharePoint.Client.SharePointOnlineCredentials] object 
        Requires the target application to have a field of type "User Name" and a field of type "Password". If there is more than one of either, the first will be used. Credentials must be set.
    .Parameter contextSiteUrl
        The URL of the on-premises site connected to the Secure store Service
    .Parameter ssTargetAppName
        The Secure Store Service target application ID/name containing the credentials to retrieve
    .Parameter credentialType
        The type of credential object to create: Windows or SharePointOnline
    .Outputs
        A client credential object of the type specified by credentialType
    .Example
        $destCred = Get-ClientCredentialFromSecureStore -contextSiteUrl $srcSite -ssTargetAppName $sssTargetAppId -credentialType SharePointOnline
    .Notes
        Name: Get-ClientCredentialFromSecureStore
        Sources: 
        Author: Brian Laws, Summit 7 Systems
        Last Edit: 4/29/2014
#>
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$contextSiteUrl,
        [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$ssTargetAppName,
        [Parameter(Mandatory=$true)][string][ValidateSet("Windows","SharePointOnline")]$credentialType
    )
    $ErrorActionPreference = "Stop"
    Write-Debug "$($MyInvocation.MyCommand.Name): Begin"

    Write-Verbose "$($MyInvocation.MyCommand.Name): Getting credentials from the Secure Store Service stored in Target Application ""$ssTargetAppName"""
    $ssCreds = Get-CredentialsFromSecureStore -contextSiteUrl $contextSiteUrl -ssTargetAppName $ssTargetAppName

    [Microsoft.BusinessData.Infrastructure.SecureStore.ISecureStoreCredential]$ssCredName = $ssCreds | Where-Object {$_.CredentialType -eq "UserName"} | Select-Object -First 1
    [Microsoft.BusinessData.Infrastructure.SecureStore.ISecureStoreCredential]$ssCredPassword = $ssCreds | Where-Object {$_.CredentialType -eq "Password"} | Select-Object -First 1

    Write-Verbose "$($MyInvocation.MyCommand.Name): Creating SharePoint Online credentials from the obtained credentials"
    [string]$credName = Convert-SecureStringToString -secureString $ssCredName.Credential

    switch ($credentialType)
    {
        "Windows" 
        {
            [System.Net.NetworkCredential]$credential = New-Object System.Net.NetworkCredential($credName, $ssCredPassword.Credential)
        }

        "SharePointOnline" 
        {
            [Microsoft.SharePoint.Client.SharePointOnlineCredentials]$credential = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($credName, $ssCredPassword.Credential)
        }
    }

    Write-Debug "$($MyInvocation.MyCommand.Name): End"
    return $credential
}

function Get-StringFromSecureStore
{
<#
    .Synopsis        
        Converts to plain text the first field of any type in the target application
    .Parameter contextSiteUrl
        The URL of the on-premises site connected to the Secure store Service
    .Parameter ssTargetAppName
        The Secure Store Service target application ID/name containing the credentials to retrieve
    .Outputs
        String from the first field in the target application
    .Example
        $destCred = Get-StringFromSecureStore -contextSiteUrl $srcSite -ssTargetAppName $sssTargetAppId
    .Notes
        Name: Get-StringFromSecureStore
        Sources: 
        Author: Brian Laws, Summit 7 Systems
        Last Edit: 4/29/2014
#>
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$contextSiteUrl,
        [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$ssTargetAppName
    )
    $ErrorActionPreference = "Stop"
    Write-Debug "$($MyInvocation.MyCommand.Name): Begin"

    Write-Verbose "$($MyInvocation.MyCommand.Name): Getting credentials from the Secure Store Service stored in Target Application ""$ssTargetAppName"""
    $ssCreds = Get-CredentialsFromSecureStore -contextSiteUrl $contextSiteUrl -ssTargetAppName $ssTargetAppName

    Write-Verbose "$($MyInvocation.MyCommand.Name): Converting the stored string to plain text"
    [string]$convertedString = Convert-SecureStringToString -secureString $ssCreds[0].Credential

    Write-Debug "$($MyInvocation.MyCommand.Name): End"
    return $convertedString
}

function Get-ValueFromSecureStoreCredentials
{
<#
    .Synopsis        
        Extracts a value out of a Secure Store Service target application credential for a given field type
    .Parameter ssCredentials
        Secure store service credential object to extract from
    .Parameter ssCredentialType
        [Microsoft.BusinessData.Infrastructure.SecureStore.SecureStoreCredentialType] - The type of field/credential to extract from
    .Outputs        
        Unencrypted string value
    .Example
        $destUser = Get-ValueFromSecureStoreCredentials -ssCredentials $ssCreds -ssCredentialType UserName
    .Notes
        Name: Get-ValueFromSecureStoreCredentials
        Sources: 
        Author: Brian Laws, Summit 7 Systems
        Last Edit: 4/29/2014
#>
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true)]$ssCredentials,
        [Parameter(Mandatory=$true)][Microsoft.BusinessData.Infrastructure.SecureStore.SecureStoreCredentialType]$ssCredentialType
    )
    $ErrorActionPreference = "Stop"
    Write-Debug "$($MyInvocation.MyCommand.Name): Begin"

    [Microsoft.BusinessData.Infrastructure.SecureStore.ISecureStoreCredential]$value = $ssCredentials | Where-Object {$_.CredentialType -eq $ssCredentialType} | Select-Object -First 1
    $valueDecrypted = Convert-SecureStringToString -secureString $value.Credential

    Write-Debug "$($MyInvocation.MyCommand.Name): End"
    return $valueDecrypted
}