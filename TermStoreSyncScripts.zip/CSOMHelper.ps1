﻿<#
    .Synopsis
        Hold all helper functions related to the SharePoint Client/Server Object Model
    .Notes
        Name: CSOMHelper.ps1
        Sources: 
        Author: Brian Laws, Summit 7 Systems
        Last Edit: 5/2/2014
#>

# Add references to SharePoint client assemblies - required for CSOM
# Change if your installation directory is not default
Write-Debug "$($MyInvocation.MyCommand.Name): Loading required assemblies"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"

# Load the Secure Store Helper in the current directory
. .\SecureStoreServiceHelper.ps1

function Get-SPClientConnection
{
<#
    .Synopsis        
        Creates a Microsoft.SharePoint.Client.ClientContext object for a SharePoint site using the given credentials (either explicitly or via a Secure Store Service target application)
    .Parameter site
         The URL of the SharePoint site to connect to
    .Parameter isSharePointOnline
       Is the site a SharePoint Online URL?
    .Parameter user
      If explicit credentials are to be used, the user name to connect with (domain\username). If specified, password is required.
    .Parameter password
        If explicit credentials are to be used, the secure string password to connect with. If specified, user is required.
    .Parameter sssSite
       The URL of the on-premises site connected to the Secure Store Service. Cannot be used with password/user.
    .Parameter sssTargetAppId
       The Secure Store Service target application ID containing the login/password to use to connect. The target application must have fields of type UserName and Password. Cannot be used with password/user.
    .Parameter requestTimeoutSec
        The number of seconds until the request times out. Default = 3 seconds
    .Outputs
        Microsoft.SharePoint.Client.ClientContext for the destination site with credentials
    .Example
        To create a ClientContext for SharePoint Online using a Secure Store Service Target Application to hold the credential:
        $context = Get-SPClientConnection -site $site -sssSite "http://onpremises" -sssTargetAppId "SharePointOnlineCredentials" -isSharePointOnline"$true
    .Example
        To create a ClientContext for an on-premises SharePoint using explicit username and password
        $context = Get-SPClientConnection -site $site -user "domain\user" -password (ConvertTo-SecureString "password" –AsPlainText –Force) -isSharePointOnline:$false
    .Notes
        Name: Get-SPClientConnection
        Sources: 
        Author: Brian Laws, Summit 7 Systems
        Last Edit: 07/14/14 (Removed the parameterset declarations and added logic to provide the same benefit)
#>
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][String]$site,
        [Parameter(Mandatory=$false)][Boolean]$isSharePointOnline = $true,
        [Parameter(Mandatory=$false)][String]$user,
        [Parameter(Mandatory=$false)][SecureString]$password,
        [Parameter(Mandatory=$false)][String]$sssSite,
        [Parameter(Mandatory=$false)][String]$sssTargetAppId,
        [Parameter(Mandatory=$false)][int]$requestTimeoutSec = 180
    )
    Write-Debug "$($MyInvocation.MyCommand.Name): Begin"
    Write-Verbose "$($MyInvocation.MyCommand.Name): Getting client connection to ""$site"" - $((Get-Date).toString())"

    # Make sure we got the required combination of user/password or sssSite/sssTargetAppId. We could put it as parameter sets in the function definition, but 
    # doing so would make calling functions more complicated (they would need to account for both parameter sets)
    if( 
        ( ([string]::IsNullOrEmpty($user) -and $password -eq $null) -and ([string]::IsNullOrEmpty($sssSite) -and [string]::IsNullOrEmpty($sssTargetAppId)) ) -or 
        ( [string]::IsNullOrEmpty($user) -and $password -ne $null ) -or
        ( ![string]::IsNullOrEmpty($user) -and $password -eq $null ) -or
        ( [string]::IsNullOrEmpty($sssSite) -and ![string]::IsNullOrEmpty($sssTargetAppId) )
    )
    {
        throw "Invalid parameters. Either provide both User and Password parameters or sssSite if sssTargetAppId is provided."
    }

    $context = New-Object Microsoft.SharePoint.Client.ClientContext($site) -Verbose:$false
    
    if ($isSharePointOnline)
    {
        Write-Verbose "$($MyInvocation.MyCommand.Name): Generating SharePoint Online client credential"
        if( ![string]::IsNullOrEmpty($sssTargetAppId) )
        {
            Write-Verbose "$($MyInvocation.MyCommand.Name): Getting credential from the secure store service"
            $destCred = Get-ClientCredentialFromSecureStore -contextSiteUrl $sssSite -ssTargetAppName $sssTargetAppId -credentialType SharePointOnline -Verbose:$false
        }
        else
        {
            Write-Verbose "$($MyInvocation.MyCommand.Name): Creating credential from explicit login/password"
            $destCred = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($user, $password) -Verbose:$false
        }
    }
    else
    {
        Write-Verbose "$($MyInvocation.MyCommand.Name): Generating Windows client credential"
        if( ![string]::IsNullOrEmpty($sssTargetAppId) )
        {
            Write-Verbose "$($MyInvocation.MyCommand.Name): Getting credential from the secure store service"
            $destCred = Get-ClientCredentialFromSecureStore -contextSiteUrl $sssSite -ssTargetAppName $sssTargetAppId -credentialType Windows -Verbose:$false
        }
        else
        {
            Write-Verbose "$($MyInvocation.MyCommand.Name): Creating credential from explicit login/password"
            $destCred = New-Object System.Net.NetworkCredential($user, $password) -Verbose:$false
        }
    }
    $context.Credentials = $destCred

    # Set the timeout
    $context.RequestTimeout = ($requestTimeoutSec * 1000)    # Convert seconds to miliseconds

    $context.Load($context.Web)
    $context.ExecuteQuery()

    Write-Verbose "$($MyInvocation.MyCommand.Name):  Done"

    Write-Debug "$($MyInvocation.MyCommand.Name): End"
    return $context
}


function Load-CSOMObject
{
<#
    .Synopsis        
        Perform the work of loading a CSOM object and executing the query. Provides the ability to do retries and handle errors.
    .Parameter contex
        An already-existing and connected [Microsoft.SharePoint.Client.ClientRuntimeContext]
    .Parameter object
        Object to be loaded via CSOM. Must pass by reference. 
    .Parameter numRetries
        The maximum number of retries if there is an error
    .Parameter numSecBetweenRetries
        The number of seconds to wait between retries
    .Parameter throwExceptionOnError
        If True, raises a fatal error to the caller. If False, only a non-fatal error will be raised.
    .Outputs
        None
    .Example
        Load-CSOMObject -ctx $contextt -object ([REF]$destChildTerms) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$true
    .Notes
        Name: Load-CSOMObject
        Sources: 
        Author: Brian Laws, Summit 7 Systems
        Last Edit: 5/2/2014
#>
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true)][Microsoft.SharePoint.Client.ClientRuntimeContext]$context,
        [Parameter(Mandatory=$true)][System.Object][REF]$object,        # We need to type as a generic Object since anything can be here. Found that you need to do it by Reference or else the type on the returned object may not match the passed-in type.
        [Parameter(Mandatory=$false)][int]$numRetries = 15,
        [Parameter(Mandatory=$false)][int]$numSecBetweenRetries = 5,
        [Parameter(Mandatory=$false)][Boolean]$throwExceptionOnError = $false
    )

    Write-Debug "$($MyInvocation.MyCommand.Name): Loading object from SharePoint using CSOM..."
    $ErrorActionPreference = "SilentlyContinue"    # We will capture the error and report it ourselves.

    [int]$retries = 0
    [boolean]$success = $false
    [string]$errorMessage = $null
    do
    {
        if($retries -gt 0)
        {
            Write-Debug "$($MyInvocation.MyCommand.Name): Retrying ($retries of $numRetries) after a $numSecBetweenRetries second pause..."
            Start-Sleep -s $numSecBetweenRetries 
        }
        
        try
        {
            Write-Debug "$($MyInvocation.MyCommand.Name): `tLoading..."
            $context.Load($object)
            $context.Load($object)
            

            Write-Debug "$($MyInvocation.MyCommand.Name): `tExecuting..."
            $context.ExecuteQuery()

            if($retries -gt 0)
            {
                Write-Debug "$($MyInvocation.MyCommand.Name): `tSuccess on retry $retries"
            }

            $success = $true
        }
        catch
        {
            # Capture the first error message for reporting later (if needed)
            if( [string]::IsNullOrEmpty($errorMessage) ) { $errorMessage = $_.Exception.Message }
            Write-Debug "$($MyInvocation.MyCommand.Name): `t`tError loading object! Error: '$($_.Exception.Message)'"
            $retries++ 
        }
    } 
    while (!$success -and $retries -le $numRetries)      # Keep looping until we have success or have run out of retries
    
    if(!$success)
    {
        Write-Debug "$($MyInvocation.MyCommand.Name): `tGenerating failure response"

        Write-Error "$($MyInvocation.MyCommand.Name): Error loading object! Error message: $errorMessage" 

        if($throwExceptionOnError)
        {
            Write-Debug "$($MyInvocation.MyCommand.Name): `t`tThrowing terminating error"
            $errorMsg = "Unable to execute CSOM query on object of type $($object.GetType()) on client connection to ""$($context.Url)"". Error message: $errorMessage"
            throw $errorMsg
        }
    }

    Write-Debug "$($MyInvocation.MyCommand.Name): Done loading object from SharePoint using CSOM. Success = $success"
}
