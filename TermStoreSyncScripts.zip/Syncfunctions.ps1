﻿<#
    .Synopsis        
        Script holds the required functions to sync a term group
    .Notes
        Name: Syncfunctions.ps1
        Sources: 
        Author: Brent Person, Microsoft, brpers@microsoft.com
        Last Edit: 07/10/2019
#>

# CHANGE NOTHING BELOW THIS LINE
##########################################

#region Functions
function Get-Term
{
	[CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true)][ValidateScript({![string]::IsNullOrEmpty($_.Web.Title)})][Microsoft.SharePoint.Client.ClientContext]$Context,
		[Parameter(Mandatory=$true)][ValidateScript({![string]::IsNullOrEmpty($_.Web.Title)})][Microsoft.SharePoint.Client.ClientContext]$srcContext,
		[Parameter(Mandatory=$true)][ValidateScript({![string]::IsNullOrEmpty($_.Name)})]$srcTerm,
		[Parameter(Mandatory=$true)][ValidateScript({![string]::IsNullOrEmpty($_.Name)})]$parent,
		[Parameter(Mandatory=$true)][ValidateScript({![string]::IsNullOrEmpty($_.Name)})]$termSet,
		[Parameter(Mandatory=$true)][ValidateNotNullOrEmpty()][string]$termName,
        [Parameter(Mandatory=$true)][string]$termId,
        [Parameter(Mandatory=$false)][Boolean]$termIsReused = $false,
        [Parameter(Mandatory=$false)][Boolean]$termIsPinned = $false,
		[Parameter(Mandatory=$false)][Boolean]$termIsPinnedRoot = $false,
		[Parameter(Mandatory=$false)][Boolean]$termIsRoot = $false,
        [Parameter(Mandatory=$false)][Boolean]$termIsSourceTerm = $false
    )

	[Int32]$lcid = (Get-Culture).LCID
	[Boolean]$newTerm = $false
	[Boolean]$NewTermFailed = $false
	$PinnedSourceTermSetID = $null
	$parentTermId = $null
	$srctTermSetName = $null
	$srcTermGroup = $null

	Write-Verbose "$($MyInvocation.MyCommand.Name): Starting the Get-Term Function."
	# reload objects
	Load-CSOMObject -context $srcContext -object ([REF]$srcTerm) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false

	if($srcTerm.IsPinned)
	{
		Write-Verbose "$($MyInvocation.MyCommand.Name): Term is pinned so getting the pinned source termset."
		[Microsoft.SharePoint.Client.Taxonomy.TermSet]$SourcePinnedTermSet = $srcTerm.PinSourceTermSet
		Load-CSOMObject -context $srcContext -object ([REF]$SourcePinnedTermSet) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false
		$PinnedSourceTermSetID = $SourcePinnedTermSet.Id
		Write-Verbose "$($MyInvocation.MyCommand.Name): Pinned source termset Id: ""$($parentTermId)""."
	}
	
	Write-Verbose "$($MyInvocation.MyCommand.Name): Reloading Objects."

	if([string]::IsNullOrEmpty($termSet.Name))
	{
		Write-Verbose "$($MyInvocation.MyCommand.Name): Destination TermSet did not load. So we are reloading the destination term store objects."
		
		[Microsoft.SharePoint.Client.Taxonomy.TermSet]$srcTermSet = $srcTerm.Termset
		Load-CSOMObject -context $srcContext -object ([REF]$srcTermSet) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false
		$srctTermSetName = $srcTermSet.Name
		
		[Microsoft.SharePoint.Client.Taxonomy.TermGroup]$srcTermGroup = $srcTermSet.Group
		Load-CSOMObject -context $srcContext -object ([REF]$srcTermGroup) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false
		$srcTermGroupName = $srcTermGroup.Name

		$destTaxonomySession = [Microsoft.SharePoint.Client.Taxonomy.TaxonomySession]::GetTaxonomySession($Context)
		Load-CSOMObject -context $Context -object ([REF]$destTaxonomySession) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false

		[Microsoft.SharePoint.Client.Taxonomy.TermStoreCollection]$destTermStores = $destTaxonomySession.TermStores
		Load-CSOMObject -context $Context -object ([REF]$destTermStores) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false

		[Microsoft.SharePoint.Client.Taxonomy.TermStore]$TermStore = $destTermStores[0]
		Load-CSOMObject -context $Context -object ([REF]$TermStore) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false

		[Microsoft.SharePoint.Client.Taxonomy.TermGroupCollection]$destTermGroups = $destTermStore.Groups
		Load-CSOMObject -context $Context -object ([REF]$destTermGroups) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false

		[Microsoft.SharePoint.Client.Taxonomy.TermGroup]$destTermGroup = $destTermGroups | ? {$_.Name -eq $srcTermGroupName}
	    Load-CSOMObject -context $Context -object ([REF]$destTermGroup) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false

		[Microsoft.SharePoint.Client.Taxonomy.TermSetCollection]$destTermSets = $destTermGroup.termsets
		Load-CSOMObject -context $Context -object ([REF]$destTermSets) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false

		[Microsoft.SharePoint.Client.Taxonomy.Termset]$TermSet = $destTermSets | ? {$_.Name -eq $srctTermSetName}
		Load-CSOMObject -context $Context -object ([REF]$TermSet) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false
	}

	if([string]::IsNullOrEmpty($Parent.Name))
	{
		Write-Verbose "$($MyInvocation.MyCommand.Name): Reloading parent Object."
		Load-CSOMObject -context $Context -object ([REF]$Parent) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false
		$ParentTermId = $Parent.Id
	}
	
	Write-Verbose "$($MyInvocation.MyCommand.Name): Reloading TermSet Terms Object."
	[Microsoft.SharePoint.Client.Taxonomy.TermCollection]$TermSetTerms = $TermSet.GetAllTerms()
	Load-CSOMObject -context $Context -object ([REF]$TermSetTerms) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false

	Write-Verbose "$($MyInvocation.MyCommand.Name): Reloading TermSet Termstore Object."
	[Microsoft.SharePoint.Client.Taxonomy.TermStore]$TermStore = $TermSet.TermStore
	Load-CSOMObject -context $Context -object ([REF]$TermStore) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false

	# validate if the term already exists in the destination termset
	If($Termid -notin $TermSetTerms.id)
	{
		Write-Verbose "$($MyInvocation.MyCommand.Name): Term ""$($TermName)"" does not exist in the destination Parent Object ""$($destTermSet.Name)""."
		write-host "Term: ""$($TermName)"" does not exist in the destination Parent Object ""$($destTermSet.Name)""." -ForegroundColor Green
		Write-Verbose "$($MyInvocation.MyCommand.Name): Checking to see if Term ""$($TermName)"" is reused or pinned."
		# First, check to see if the item is the source term reused or not
		if(($TermIsSourceTerm -and ($TermIsReused -or !($TermIsReused))))
		{
			Write-Verbose "$($MyInvocation.MyCommand.Name): Term ""$TermName"" is the source term so create it."
			Write-Verbose "$($MyInvocation.MyCommand.Name): Creating Term ""$TermName""."

			If($TermIsRoot)
			{
				Write-Verbose "$($MyInvocation.MyCommand.Name): Term: ""$TermName"" is a root term."
				[Microsoft.SharePoint.Client.Taxonomy.Term]$Term = $TermSet.CreateTerm($TermName,$Lcid,$TermId)
				Load-CSOMObject -context $Context -object ([REF]$TermSet) -numSecBetweenRetries 5 -numRetries 6 -throwExceptionOnError:$false
				$newTerm = $true
			}
			Else
			{
				Write-Verbose "$($MyInvocation.MyCommand.Name): Term: ""$TermName"" is not a root term so we must create it under the parent: ""$($Parent.Name)""."
				[Microsoft.SharePoint.Client.Taxonomy.Term]$Term = $Parent.CreateTerm($TermName,$Lcid,$TermId)
				Load-CSOMObject -context $Context -object ([REF]$Parent) -numSecBetweenRetries 5 -numRetries 6 -throwExceptionOnError:$false
				$newTerm = $true
			}
		}
		Elseif(($TermIsReused -and !($TermIsSourceTerm) -and !($TermIsPinned))) 
		{
			Write-Verbose "$($MyInvocation.MyCommand.Name): Term: ""$TermName"" is a reused term and it's not the source term." 
			Write-Verbose "$($MyInvocation.MyCommand.Name): Checking to see if the source term exists in the destination termstore" 
			[Microsoft.SharePoint.Client.Taxonomy.Term]$reusedTerm = $TermStore.GetTerm($TermId)
			Load-CSOMObject -context $Context -object ([REF]$reusedTerm) -numSecBetweenRetries 5 -numRetries 6 -throwExceptionOnError:$false

			if(!([string]::IsNullOrEmpty($reusedTerm.Name)))
			{
				Write-Verbose "$($MyInvocation.MyCommand.Name): Source Term Does exist!"
				
				If($TermIsRoot)
				{
					[Microsoft.SharePoint.Client.Taxonomy.Term]$Term = $TermSet.ReuseTerm($reusedTerm, $false)
					Load-CSOMObject -context $Context -object ([REF]$TermSet) -numSecBetweenRetries 5 -numRetries 6 -throwExceptionOnError:$false
					$newTerm = $true
				}
				Else
				{
					[Microsoft.SharePoint.Client.Taxonomy.Term]$Term = $Parent.ReuseTerm($reusedTerm, $false)
					Load-CSOMObject -context $Context -object ([REF]$Parent) -numSecBetweenRetries 5 -numRetries 6 -throwExceptionOnError:$false
					$newTerm = $true
				}
			}
			else
			{
				$message = "Unable to re-use the term because it does not yet exist in the term store. Please try again after the original term has been created."
				Write-Verbose "$($MyInvocation.MyCommand.Name): `t`t$message"
				Write-Host "$message" -ForegroundColor Red
				$NewTermFailed = $true
				continue
			}	
		}
		Elseif($termIsPinned -and $TermIsPinnedRoot)
		{
			Write-Verbose "$($MyInvocation.MyCommand.Name): Term ""$TermName"" is a pinned term and it's the pinned root."
			Write-Verbose "$($MyInvocation.MyCommand.Name): Getting the pinned terms source pinned termset so we can pin the right term."
			[Microsoft.SharePoint.Client.Taxonomy.Termset]$PinnedTermsSourceTermSet = $TermStore.GetTermSet($PinnedSourceTermSetID)
			Load-CSOMObject -context $Context -object ([REF]$PinnedTermsSourceTermSet) -numSecBetweenRetries 5 -numRetries 6 -throwExceptionOnError:$false
            If(!([string]::IsNullOrEmpty($PinnedTermsSourceTermSet.Name)))
            {
                # Get the Source Pinned Term
			    Write-Verbose "$($MyInvocation.MyCommand.Name): Getting the source pinned term."
			    [Microsoft.SharePoint.Client.Taxonomy.Term]$SourcePinnedTerm = $pinnedTermsSourceTermSet.GetTerm($termId)
			    Load-CSOMObject -context $Context -object ([REF]$SourcePinnedTerm) -numSecBetweenRetries 5 -numRetries 6 -throwExceptionOnError:$false

                If(!([string]::IsNullOrEmpty($SourcePinnedTerm.Name)))
			    {
                    # Check to see if we have the Source Pinned Term if we do Pin the term
			        Write-Verbose "$($MyInvocation.MyCommand.Name): Validating if we loaded the source pinned term."
				    If($TermIsRoot)
				    {
					    Write-Verbose "$($MyInvocation.MyCommand.Name): source pinned term loaded pinning term ""$($SourcePinnedTerm.Name)""."
					    [Microsoft.SharePoint.Client.Taxonomy.Term]$Term = $TermSet.ReuseTermWithPinning($SourcePinnedTerm)
					    Load-CSOMObject -context $destContext -object ([REF]$TermSet) -numSecBetweenRetries 5 -numRetries 6 -throwExceptionOnError:$false
					    $newTerm = $true
				    }
				    Else
				    {
					    Write-Verbose "$($MyInvocation.MyCommand.Name): source pinned term loaded pinning term ""$($SourcePinnedTerm.Name)""."
					    [Microsoft.SharePoint.Client.Taxonomy.Term]$Term = $Parent.ReuseTermWithPinning($SourcePinnedTerm)
					    Load-CSOMObject -context $Context -object ([REF]$Parent) -numSecBetweenRetries 5 -numRetries 6 -throwExceptionOnError:$false
					    $newTerm = $true
				    }
			    }
                Else
			    {
				    $message = "Unable to Pin the term because the source Pinned Term does not yet exist in the term store. Please try again after the original term has been created."
				    Write-Verbose "$($MyInvocation.MyCommand.Name): `t`t$message"
					Write-Host "$message" -ForegroundColor Red
					$NewTermFailed = $true
				    continue
			    }
            }
            else
            {
				$message = "Source Pinned Termset with ID: ""$PinnedSourceTermSetID"" does not yet exist in the Destination TermStore."
                Write-Verbose "$($MyInvocation.MyCommand.Name): `t`t$message"
				Write-Host "$message" -ForegroundColor Red
				$NewTermFailed = $true
                continue
            }				
		}
	}
	Else
	{
		Write-Verbose "$($MyInvocation.MyCommand.Name): Term ""$TermName"" already exists in the destination."
		Write-Host "Term ""$TermName"" already exists in the destination. Getting Existing Term from Destination." -ForegroundColor Yellow
		[Microsoft.SharePoint.Client.Taxonomy.Term]$Term = $TermSetTerms.GetById($termId)
		Load-CSOMObject -context $Context -object ([REF]$Term) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false
		If([string]::IsNullOrEmpty($Term.Name))
		{
			Write-Verbose "$($MyInvocation.MyCommand.Name): Unable to get the Term: ""$termName"" at the destination term store."
			Write-Host "Unable to get the existing Term: ""$termName"" at the destination term store." -ForegroundColor Red
			continue
		}
		else
		{
			Write-Verbose "$($MyInvocation.MyCommand.Name): We were able to get the Term: ""$termName"" at the destination term store."
			$newTerm = $false
		}	
	}	

	if($newTerm)
	{
		Write-Verbose "$($MyInvocation.MyCommand.Name): `tCommitting the transaction..."
		$TermStore.CommitAll()
		$TermStore.UpdateCache()
		Start-Sleep -Seconds 2
		Load-CSOMObject -context $Context -object ([REF]$Term) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false
	}
	
	return $Term
}

function WalkTerm
{
	[CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true)][ValidateScript({![string]::IsNullOrEmpty($_.Name)})]$srcTerm,
		[Parameter(Mandatory=$true)][ValidateScript({![string]::IsNullOrEmpty($_.Name)})]$parent,
		[Parameter(Mandatory=$true)][ValidateScript({![string]::IsNullOrEmpty($_.Name)})]$destTermSet,
        [Parameter(Mandatory=$true)][ValidateScript({![string]::IsNullOrEmpty($_.Web.Title)})][Microsoft.SharePoint.Client.ClientContext]$srcContext,
		[Parameter(Mandatory=$true)][ValidateScript({![string]::IsNullOrEmpty($_.Web.Title)})][Microsoft.SharePoint.Client.ClientContext]$destContext
    )
	Load-CSOMObject -context $srcContext -object ([REF]$srcTerm) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false
	Load-CSOMObject -context $destContext -object ([REF]$destTermSet) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false
	$srcContext.load($srcTerm.terms)
	$srcContext.ExecuteQuery()

	Write-Verbose "$($MyInvocation.MyCommand.Name): Getting the destination Term ""$($srcTerm.Name)""."

	$destTerm = Get-Term -Context $destContext -srcContext $srcContext -srcTerm $srcTerm -TermSet $destTermSet -TermName $srcTerm.Name -termId $srcTerm.Id -termIsRoot $srcTerm.IsRoot -termIsReused $srcTerm.IsReused -termIsPinned $srcTerm.IsPinned -TermIsPinnedRoot $srcTerm.IsPinnedRoot -termIsSourceTerm $srcTerm.IsSourceTerm -parent $parent
	If($destTerm.Name -eq $null)
	{
		Write-Verbose "$($MyInvocation.MyCommand.Name): Failed to Returned destination Term"
		Write-Host "Failed to Returned destination Term" -ForegroundColor Red
		continue
	}
	else
	{
		Write-Verbose "$($MyInvocation.MyCommand.Name): Returned destination Term ""$($destTerm.Name)"" ""$($destTerm.Id)"""
		Write-Verbose "$($MyInvocation.MyCommand.Name): Syncing Source Term: ""$($srcTerm.Name)"":""$($srcTerm.Id)"" with Destination Term ""$($destTerm.Name)"":""$($destTerm.Id)"""
		SyncTermInfo -srcTerm $srcTerm -destTerm $destTerm -srcContext $srcContext -destContext $destContext
	}


	if($destTerm.Name -ne $null)
	{
		if($srcTerm.terms.count -gt 0)
		{
			Write-Verbose "$($MyInvocation.MyCommand.Name): Walking the Term: ""$($destTerm.Name)"" Child terms."

			foreach($childterm in $srcTerm.Terms)
			{
				Load-CSOMObject -context $srcContext -object ([REF]$childterm) -numSecBetweenRetries 5 -numRetries 6 -throwExceptionOnError:$false
				Write-Verbose "$($MyInvocation.MyCommand.Name): Walking ""$($Childterm.Name)"" ""$($Childterm.Id)"""
				WalkTerm -srcTerm $childterm -destTermSet $destTermSet -srcContext $srcContext -destContext $destContext -parent $destTerm
			}
		}	  
		Else
		{
			Write-Verbose "$($MyInvocation.MyCommand.Name): Done walking Child terms."
		}
	}
	Else
	{
		$message = """$($srcTerm.Name)"" failed to return from Destination. Skipping Child Terms."
        Write-Verbose "$($MyInvocation.MyCommand.Name): `t`t$message"
		Write-Host "$message" -ForegroundColor Red
        continue
	}	
}

function SyncTermInfo
{
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true)][ValidateScript({![string]::IsNullOrEmpty($_.Web.Title)})][Microsoft.SharePoint.Client.ClientContext]$destContext,
        [Parameter(Mandatory=$true)][ValidateScript({![string]::IsNullOrEmpty($_.Web.Title)})][Microsoft.SharePoint.Client.ClientContext]$srcContext,
        [Parameter(Mandatory=$true)][Microsoft.SharePoint.Client.Taxonomy.Term]$destTerm,
        [Parameter(Mandatory=$true)][Microsoft.SharePoint.Client.Taxonomy.Term]$srcTerm
    )

	# We must change the $UPN value to match your environment
	[string]$UPN = "@personfamilyllc.com"
    $ErrorActionPreference = "Continue"
	Write-Verbose "$($MyInvocation.MyCommand.Name): Checking to see if we need to load Source or Destination objects."
    #region Get the destination term objects if needed
    $updateDestTerm = $false
    if( !($destTerm.IsObjectPropertyInstantiated("Labels")) )
    {
        $destContext.Load($destTerm.Labels)
        $updateDestTerm = $true
    }
    if( !($destTerm.IsObjectPropertyInstantiated("Terms")) )
    {
        $destContext.Load($destTerm.Terms)
        $updateDestTerm = $true
    }
    if($updateDestTerm)
    {
        Write-Verbose "$($MyInvocation.MyCommand.Name): `tGetting the destination term ""$($destTerm.Name)"" and its objects"
        Load-CSOMObject -context $destContext -object ([REF]$destTerm) -numSecBetweenRetries 5 -numRetries 6 -throwExceptionOnError:$false
    }
    #endregion

    #region Get the source term objects if needed
    $updateSrcTerm = $false
    if( !($srcTerm.IsObjectPropertyInstantiated("Labels")) )
    {
        $srcContext.Load($srcTerm.Labels)
        $updateSrcTerm = $true
    }
    if( !($srcTerm.IsObjectPropertyInstantiated("Terms")) )
    {
        $srcContext.Load($srcTerm.Terms)
        $updateSrcTerm = $true
    }
    if($updateSrcTerm)
    {
        Write-Verbose "$($MyInvocation.MyCommand.Name): `tGetting the source term ""$($srcTerm.Name)"" and its objects"
        Load-CSOMObject -context $srcContext -object ([REF]$srcTerm) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false
    }
    #endregion

    #region Sync properties regardless of term type. 
    # They can exist regardless of whether or not the term was re-used and/or Pinned
	Write-Verbose "$($MyInvocation.MyCommand.Name): Syncing term properties regardless of term type."
    # Add any local properties that are needed
    if($srcTerm.LocalCustomProperties.Count -gt 0)
    {
		if($srcTerm.LocalCustomProperties.Key.Count -gt 0)
		{
			Write-Debug "$($MyInvocation.MyCommand.Name): Processing local custom properties for ""$($srcTerm.Name)"""
			Write-Verbose "$($MyInvocation.MyCommand.Name): Processing local custom properties for ""$($srcTerm.Name)"""
			foreach($srcProperty in $srcTerm.LocalCustomProperties.Keys)
			{
				if($destTerm.LocalCustomProperties[$srcProperty] -ne $srcTerm.LocalCustomProperties[$srcProperty])
				{
					Write-Debug "$($MyInvocation.MyCommand.Name): Updating the Local Custom Property ""$srcProperty"""
					Write-Verbose "$($MyInvocation.MyCommand.Name): Updating the Local Custom Property ""$srcProperty"" for ""$($destTerm.Name)"""
					$destTerm.SetLocalCustomProperty($srcProperty, $srcTerm.LocalCustomProperties[$srcProperty])
					$needsUpdate = $true       
				}
			}
		}
    }

    if($destTerm.IsAvailableForTagging -ne $srcTerm.IsAvailableForTagging) 
    { 
        Write-Debug "$($MyInvocation.MyCommand.Name): Found discrepancy in Is Available For Tagging. Updating it."
        Write-Verbose "$($MyInvocation.MyCommand.Name): Found discrepancy in Is Available For Tagging. Updating it."
        $destTerm.IsAvailableForTagging = $srcTerm.IsAvailableForTagging 
		$needsUpdate = $true       
    }

    # Deprecate the term if needed
    if($destTerm.IsDeprecated -ne $srcTerm.IsDeprecated)
    {
        Write-Verbose "$($MyInvocation.MyCommand.Name): Found discrepancy in Is Deprecated. Updating it."
        Write-Debug "$($MyInvocation.MyCommand.Name): Found discrepancy in Is Deprecated. Updating it."
        $destTerm.Deprecate($srcTerm.IsDeprecated)
        $needsUpdate = $true       
    }
    
    if($needsUpdate)
    {
        Write-Verbose "$($MyInvocation.MyCommand.Name): Done processing term ""$($srcTerm.Name)"". Committing all changes."
        $destTerm.TermStore.CommitAll()
		$destTerm.TermStore.UpdateCache()
        Start-Sleep -Seconds 2     # Give some time for the commit to complete
    }

    $needsUpdate = $false
	#endregion

	#region Sync Term properties per term type
	Write-Verbose "$($MyInvocation.MyCommand.Name): Syncing term properties per term type."
	# Source Terms
	if($srcTerm.IsSourceTerm -and ($srcTerm.IsReused -or !($srcTerm.IsReused)))
	{
		if($destTerm.Owner -ne $srcTerm.Owner)
		{
			Write-Debug "$($MyInvocation.MyCommand.Name): Found discrepancy in the Owner. Updating it."
			Write-Verbose "$($MyInvocation.MyCommand.Name): Found discrepancy in the Owner. Updating it."
			$srcOwner = $srcTerm.Owner
			$prefix = $srcOwner.Replace("w","f")
			$membership = $prefix.Replace("teckcominco\","membership|")
			$newOwner = $membership + $UPN
			$destTerm.Owner = $newOwner
			$needsUpdate = $true
		}

		if($destTerm.Description -ne $srcTerm.Description) 
		{ 
			Write-Debug "$($MyInvocation.MyCommand.Name): Found discrepancy in the Description. Updating it."
			Write-Verbose "$($MyInvocation.MyCommand.Name): Found discrepancy in the Description. Updating it."
			$destTerm.SetDescription($srcTerm.Description, $lcid) 
			$needsUpdate = $true       
		}

		if($destTerm.Labels.AreItemsAvailable -and $srcTerm.Labels.AreItemsAvailable)
		{
			# Add any labels needed and, if it already exists, set the default label appropriately
			foreach($srcLabel in $srcTerm.Labels)
			{
				[Microsoft.SharePoint.Client.Taxonomy.Label]$destLabel = $destTerm.Labels | Where-object {$_.Value -eq $srcLabel.Value -and $_.Language -eq $srcLabel.Language}
				if($destLabel -eq $null)
				{
                    Write-Verbose "$($MyInvocation.MyCommand.Name): Adding the Label ""$($srcLabel.Value)"""
					Write-Debug "$($MyInvocation.MyCommand.Name): Adding the Label ""$($srcLabel.Value)"""
					$destTerm.CreateLabel($srcLabel.Value, $srcLabel.Language, $srcLabel.IsDefaultForLanguage) | Out-Null
					$needsUpdate = $true       
				}
				else
				{
					if($srcLabel.IsDefaultForLanguage -ne $destLabel.IsDefaultForLanguage)
					{
						Write-Verbose "$($MyInvocation.MyCommand.Name): Updating the Default Label"
                        Write-Debug "$($MyInvocation.MyCommand.Name): Updating the Default Label"
						$destLabel.IsDefaultForLanguage = $srcLabel.IsDefaultForLanguage
						$needsUpdate = $true       
					}
				}
			}   
		}                
		else
		{
			Write-Host "Source or destination term labels do not exist or have not yet been initialized" -ForegroundColor Yellow
		}

		# Set Term Owners

		 # Sync custom properties
		if($srcTerm.CustomProperties.Count -gt 0)
		{
            Write-Verbose "$($MyInvocation.MyCommand.Name): Processing custom properties for ""$($srcTerm.Name)"""
			Write-Debug "$($MyInvocation.MyCommand.Name): Processing custom properties for ""$($srcTerm.Name)"""
			foreach($srcProperty in $srcTerm.CustomProperties.Keys)
			{
				if($destTerm.CustomProperties[$srcProperty] -ne $srcTerm.CustomProperties[$srcProperty])
				{
                    Write-Verbose "$($MyInvocation.MyCommand.Name): Updating the Custom Property ""$srcProperty"""
					Write-Debug "$($MyInvocation.MyCommand.Name): Updating the Custom Property ""$srcProperty"""
					$destTerm.SetCustomProperty($srcProperty, $srcTerm.CustomProperties[$srcProperty])
					$needsUpdate = $true       
				}
			}
		}

		if($destTerm.CustomSortOrder -ne $srcTerm.CustomSortOrder) 
        { 
            Write-Verbose "$($MyInvocation.MyCommand.Name): Found discrepancy in the Custom Sort Order. Updating it."
            Write-Debug "$($MyInvocation.MyCommand.Name): Found discrepancy in the Custom Sort Order. Updating it."
            $destTerm.CustomSortOrder = $srcTerm.CustomSortOrder 
            $needsUpdate = $true       
        }
	}

	# Reused Terms that aren't source terms and pinned terms that are the pinned root
	if(($srcTerm.IsReused -and !($srcTerm.IsSourceTerm)) -or ($srcTerm.IsPinned -and $srcTerm.IsPinnedRoot))
	{
		if($destTerm.CustomSortOrder -ne $srcTerm.CustomSortOrder) 
        { 
            Write-Verbose "$($MyInvocation.MyCommand.Name): Found discrepancy in the Custom Sort Order. Updating it."
            Write-Debug "$($MyInvocation.MyCommand.Name): Found discrepancy in the Custom Sort Order. Updating it."
            $destTerm.CustomSortOrder = $srcTerm.CustomSortOrder 
            $needsUpdate = $true       
        }
	}

	if($needsUpdate)
    {
        Write-Host "Done processing term ""$($srcTerm.Name)"" properties. Committing all changes." -ForegroundColor Yellow
        $destTerm.TermStore.CommitAll()
		$destTerm.TermStore.UpdateCache()
        Start-Sleep -Seconds 2     # Give some time for the commit to complete
    }
	#endregion
    Write-Host "Done syncing term info." -ForegroundColor Yellow
}

function SyncTermSetInfo
{
	[CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true)][ValidateScript({![string]::IsNullOrEmpty($_.Web.Title)})][Microsoft.SharePoint.Client.ClientContext]$destContext,
        [Parameter(Mandatory=$true)][ValidateScript({![string]::IsNullOrEmpty($_.Web.Title)})][Microsoft.SharePoint.Client.ClientContext]$srcContext,
        [Parameter(Mandatory=$true)][ValidateScript({![string]::IsNullOrEmpty($_.Name)})][Microsoft.SharePoint.Client.Taxonomy.TermSet]$destTermSet,
        [Parameter(Mandatory=$true)][ValidateScript({![string]::IsNullOrEmpty($_.Name)})][Microsoft.SharePoint.Client.Taxonomy.TermSet]$srcTermSet
    )

	# We must change the $UPN value to match your environment
	[string]$UPN = "@personfamilyllc.com"
	$ErrorActionPreference = "Continue"
	[Boolean]$needsUpdate = $false 

	if($destTermSet.TermStore.ServerObjectIsNull)
	{
		$destContext.Load($destTermSet.TermStore)
		$destContext.ExecuteQuery()
	}

	#Set the contact and Stake Holders
    Write-Verbose "$($MyInvocation.MyCommand.Name): Adding Termset Contact and Stakeholders if they exist"

	if($destTermSet.Contact -ne $srcTermSet.Contact)
	{
		Write-Verbose "$($MyInvocation.MyCommand.Name): Found discrepency in TermSet Contact. Updating object to: ""$($srcTermSet.Contact)""."
		$destTermSet.Contact = $srcTermSet.Contact
		$needsUpdate = $true
	}

	if($destTermSet.Owner -ne $srcTermSet.Owner)
	{
        $srcOwner = $srcTermSet.Owner
        $prefix = $srcOwner.Replace("w","f")
        $membership = $prefix.Replace("teckcominco\","membership|")
        $newOwner = $membership + $UPN
		Write-Verbose "$($MyInvocation.MyCommand.Name): Found discrepency in TermSet Owner. Updating object owner to: ""$($newOwner)""."
		$destTermSet.Owner = $newOwner
		$needsUpdate = $true
	}

	if($srcTermSet.Stakeholders.count -gt 0)
	{
		if($destTermSet.Stakeholders -ne $srcTermSet.Stakeholders)
		{
			$Stakeholdersarray = @()
			$Stakeholdersarray += $srcTermSet.Stakeholders
			foreach($item in $Stakeholdersarray)
			{
				$prefix = $item.Replace("w","f")
				$membership = $prefix.Replace("teckcominco\","membership|")
				$newStakeHolder = $membership + $UPN
				$DestTermSet.AddStakeholder($newStakeHolder) 
				$needsUpdate = $true
			}
		}
	}

    if($destTermSet.CustomSortOrder -ne $srcTermSet.CustomSortOrder)
    {
        Write-Verbose "$($MyInvocation.MyCommand.Name): Found discrepancy in the Custom Sort Order. Will update."
        $destTermSet.CustomSortOrder = $srcTermSet.CustomSortOrder
        $needsUpdate = $true
    }
    
    if($destTermSet.Description -ne $srcTermSet.Description)
    {
        Write-Verbose "$($MyInvocation.MyCommand.Name): Found discrepancy in the Description. Will update."
        $destTermSet.Description = $srcTermSet.Description
        $needsUpdate = $true
    }

    if($destTermSet.IsAvailableForTagging -ne $srcTermSet.IsAvailableForTagging)
    {
        Write-Verbose "$($MyInvocation.MyCommand.Name): Found discrepancy in Available for Tagging. Will update."
        $destTermSet.IsAvailableForTagging = $srcTermSet.IsAvailableForTagging
        $needsUpdate = $true
    }
    
    if($destTermSet.IsOpenForTermCreation -ne $srcTermSet.IsOpenForTermCreation)
    {
        Write-Verbose "$($MyInvocation.MyCommand.Name): Found discrepancy in the Submission Policy. Will update."
        $destTermSet.IsOpenForTermCreation = $srcTermSet.IsOpenForTermCreation
        $needsUpdate = $true
    }

    # Sync custom properties
    if($srcTermSet.CustomProperties.Count -gt 0)
    {
        Write-Verbose "$($MyInvocation.MyCommand.Name): Examining Custom Properties on ""$($srcTermSet.Name)"""
        foreach($srcProperty in $srcTermSet.CustomProperties.Keys)
        {
            if($destTermSet.CustomProperties[$srcProperty] -ne $srcTermSet.CustomProperties[$srcProperty])
            {
                Write-Verbose "$($MyInvocation.MyCommand.Name): Found discrepancy in Custom Property ""$($srcProperty)"". Will update."
                $destTermSet.SetCustomProperty($srcProperty, $srcTermSet.CustomProperties[$srcProperty])
                $needsUpdate = $true
            }
        }
    }
	# Write all the changes to this point
    if($needsUpdate)
    {
        Write-Verbose "$($MyInvocation.MyCommand.Name): Updating the term set ""$($srcTermSet.Name)"" and committing all changes"
        $destContext.ExecuteQuery()
        $destTermSet.TermStore.CommitAll()
		$destTermSet.TermStore.UpdateCache()
        Start-Sleep -Seconds 2     # Give some time for the commit to complete
        Write-Verbose "$($MyInvocation.MyCommand.Name): Done!"
    }
    else
    {
        Write-Verbose "$($MyInvocation.MyCommand.Name): No property updates needed for the term set ""$($srcTermSet.Name)"""
    }
}

function SyncTermGroupInfo
{
	[CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true)][ValidateScript({![string]::IsNullOrEmpty($_.Web.Title)})][Microsoft.SharePoint.Client.ClientContext]$destContext,
        [Parameter(Mandatory=$true)][ValidateScript({![string]::IsNullOrEmpty($_.Web.Title)})][Microsoft.SharePoint.Client.ClientContext]$srcContext,
        [Parameter(Mandatory=$true)][ValidateScript({![string]::IsNullOrEmpty($_.Name)})][Microsoft.SharePoint.Client.Taxonomy.TermGroup]$destTermGroup,
        [Parameter(Mandatory=$true)][ValidateScript({![string]::IsNullOrEmpty($_.Name)})][Microsoft.SharePoint.Client.Taxonomy.TermGroup]$srcTermGroup
    )
	#[string]$UPN = "@personfamilyllc.com"
	$ErrorActionPreference = "Continue"
	[Boolean]$needsUpdate = $false
    # Synchronize term group properties
	if($destTermGroup.TermStore.ServerObjectIsNull -or [string]::IsNullOrEmpty($destTermGroup.Name))
	{
		$destContext.Load($destTermGroup.TermStore)
		$destContext.ExecuteQuery()
	}

    if($srcTermGroup.Description -ne $destTermGroup.Description)
    {
        Write-Verbose "$($MyInvocation.MyCommand.Name): Found term group description discrepancy. Updating."
        $destTermGroup.Description = $srcTermGroup.Description
        $needsUpdate = $true
    }

	<#if($srcTermGroup.ContributorPrincipalNames.count -gt 0)
	{
		if($destTermGroup.ContributorPrincipalNames -ne $srcTermGroup.ContributorPrincipalNames)
		{
			Write-Verbose "$($MyInvocation.MyCommand.Name): Found term group Contributor discrepancy. Updating."
			$PrincipalNamesarray = @()
			$PrincipalNamesarray  += $srcTermGroup.ContributorPrincipalNames
			foreach($item in $PrincipalNamesarray)
			{
				$prefix = $item.Replace("w","f")
				$membership = $prefix.Replace("teckcominco\","membership|")
				$newContributor = $membership + $UPN
				$destTermGroup.AddContributor($newContributor) 
				$needsUpdate = $true  
			}
			$needsUpdate = $true
		}	
	}

	if($srcTermGroup.GroupManagerPrincipalNames.count -gt 0)
	{
		if($destTermGroup.GroupManagerPrincipalNames -ne $srcTermGroup.GroupManagerPrincipalNames)
		{
			Write-Verbose "$($MyInvocation.MyCommand.Name): Found term group description discrepancy. Updating."
			$GroupManagerArray = @()
			$GroupManagerArray += $srcTermGroup.GroupManagerPrincipalNames
			foreach($item in $PrincipalNamesarray)
			{
				$prefix = $item.Replace("w","f")
				$membership = $prefix.Replace("teckcominco\","membership|")
				$newManager = $membership + $UPN 
				$destTermGroup.AddGroupManager($newManager)
				$needsUpdate = $true  
			}
			$needsUpdate = $true
		}	
	}
	#>

	if($needsUpdate)
    {
        Write-Verbose "$($MyInvocation.MyCommand.Name): Updating the term Group ""$($srcTermGroup.Name)"" and committing all changes"
        $destContext.ExecuteQuery()
        $destTermGroup.TermStore.CommitAll()
		$destTermGroup.TermStore.UpdateCache()

        Start-Sleep -Seconds 2     # Give some time for the commit to complete
        Write-Verbose "$($MyInvocation.MyCommand.Name): Done!"
    }
    else
    {
        Write-Verbose "$($MyInvocation.MyCommand.Name): No property updates needed for the term group ""$($srcTermGroup.Name)"""
    }
}

Function Log-Start
{
    If((Test-Path -Path  $global:LogFile))
	{
		Remove-Item -Path  $global:LogFile -Force
		New-Item -Path $LogPath -Value $LogName -ItemType File    
		Add-Content -Path  $global:LogFile -Value "Begin trace logging for Monitoring Tool [$([DateTime]::Now)]."
		Add-Content -Path  $global:LogFile -Value "***************************************************************************************************"
	}
}

Function Log-Write
{
  Param ([string] $level="INFO",[Parameter(Mandatory=$true)][string]$Message)
  Add-Content -Path $global:LogFile -Value $([string]::Format("{0}`t{1}`t{2}",$([DateTime]::Now).ToString('yyyy/MM/dd  HH:mm:ss'), $level ,$Message)) 
}

function Is-ISE
{
    # Determine whether or not we're running in the ISE. 
    return $host.Name -eq "Windows PowerShell ISE Host" 
}

function Get-LogFolderWithDate
{
    [CmdletBinding()]
    Param
    (
        [string]$scriptPath,
        [DateTime]$date
    )
    
    $month = $date.Month.ToString()
    if ($date.Month -lt 10)
    {
        $month = "0" + $month
    }

    $day = $date.Day.ToString()
    if ($date.Day -lt 10)
    {
        $day = "0" + $day
    }

    $hour = $date.Hour.ToString()
    if ($date.Hour -lt 10)
    {
        $hour = "0" + $hour
    }

    $minute = $date.Minute.ToString()
    if ($date.Minute -lt 10)
    {
        $minute = "0" + $minute
    }

    $second = $date.Second.ToString()
    if ($date.Second -lt 10)
    {
        $second = "0" + $second
    }

    $logFolder = Join-Path $scriptPath ($date.Year.ToString() + $month + $day + "-" + $hour + $minute + $second)

    if(!(Test-Path -Path $logFolder -PathType Container))
    {
        New-Item $logFolder -ItemType directory
    }

    return $logFolder
}

function Start-TranscriptHelper
{
    # Start the transcript if not in the ISE
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$false)]$scriptName,
        [Parameter(Mandatory=$false)]$logFolder
    )

    # Start the transcript if not in the ISE
    if (!(Is-ISE))
    {
        $fileName = $scriptName + "_Transcript.log"
        $transcriptPath = Join-Path $logFolder $fileName

        try
        {
            Write-Verbose "Starting transcript at $transcriptPath"
            Start-Transcript -Path $transcriptPath -Force
        }
        catch
        {
            Write-Verbose "Transcript is already running. Stopping and restarting."
            Stop-Transcript
            Start-Transcript -Path $transcriptPath -Force
        }
    }
}

function Stop-TranscriptHelper
{
    # Stop the transcript if not in the ISE
    if (!(Is-ISE))
    {
        # If a transcript isn't currently running, the Stop-Transcript will fail. -ErrorAction doesn't work (bug). So we need to swallow any errors
        $ErrorActionPreference = "SilentlyContinue"
        Stop-Transcript
    }
}
#endregion