﻿<#
       ## DISCLAIMER:
	   ## Copyright (c) Microsoft Corporation. All rights reserved. This
	   ## script is made available to you without any express, implied or
	   ## statutory warranty, not even the implied warranty of
	   ## merchantability or fitness for a particular purpose, or the
	   ## warranty of title or non-infringement. The entire risk of the
       ## use or the results from the use of this script remains with you

    .Synopsis        
        Script to migrate an OnPrem term store to SharePoint Online
        This Script Assumes you've installed SharePoint in the default location
        This Script currently does not support user mapping to SPO user
        This Script currently only supports a single TermStore associated with the OnPrem web application and it must be the default TermStore
        
        **Change the location of the sharepoint client .dll files to fit your environment**

    .Prerequisites
       SharePoint Online Client SDK version 16.0.7018.1200 or higher
       TermStore Administrator Rights
    
    .Example
        '.\MigrateOnPremTermStoreToSPO.ps1' -SrcSiteUrl https://www.contoso.com -SrcUsername contoso\admin -SrcPassword **** -SPOSiteUrl https://contoso.sharepoint.com -SPOUsername Admin@contoso.onmicrosoft.com -SPOPassword **** -GroupList ("Group1","Group2","Group3","Group4")
    
    .Notes
        Name: MigrateOnPremTermStoreToSPO.ps1
        Author: Brent Person, Microsoft, brpers@microsoft.com
        Created: 7/10/2020
        Last Edit: 07/22/2020
#>

[CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true)][string]$SrcSiteUrl, 
        [Parameter(Mandatory=$true)][string]$SrcUsername,
        [Parameter(Mandatory=$true)][string]$SrcPassword,
        [Parameter(Mandatory=$true)][string]$SPOSiteUrl,
        [Parameter(Mandatory=$true)][string]$SPOUsername,
        [Parameter(Mandatory=$true)][string]$SPOPassword,
        [Parameter(Mandatory=$true)][string[]]$GroupList = @()
    )

# Add references to SharePoint client assemblies - required for CSOM
# Change if your installation directory is not default

Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Runtime.dll"
Add-Type -Path "C:\Program Files\Common Files\Microsoft Shared\Web Server Extensions\16\ISAPI\Microsoft.SharePoint.Client.Taxonomy.dll"

        #This code calls to a Microsoft web endpoint to track how often it is used. 
        #No data is sent on this call other than the application identifier
        Add-Type -AssemblyName System.Net.Http
        $client = New-Object -TypeName System.Net.Http.Httpclient
        $cont = New-Object -TypeName System.Net.Http.StringContent("", [system.text.encoding]::UTF8, "application/json")
        $tsk = $client.PostAsync("https://msapptracker.azurewebsites.net/api/Hits/a5cbcde0-9c3d-49e1-af19-74da4353f809",$cont)

$StartTime = Get-Date
write-host "Starting at $StartTime"
$stopwatch = [system.diagnostics.stopwatch]::StartNew()

#region functions
function GetContext
{
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true)][String]$SiteUrl,
        [Parameter(Mandatory=$true)][String]$UserName,
        [Parameter(Mandatory=$true)][String]$Password,
        [Parameter(Mandatory=$false)][Switch]$IsSPO
    )

    If($IsSPO.IsPresent)
    {
        $SecurePwd = ConvertTo-SecureString $Password -AsPlainText -Force
        $DestCtx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteUrl)
        $Credentials = New-Object Microsoft.SharePoint.Client.SharePointOnlineCredentials($Username, $SecurePwd)
        $DestCtx.Credentials = $Credentials

        # Decorate our CSOM Calls to SPO to help with throttling
        # https://docs.microsoft.com/en-us/sharepoint/dev/general-development/how-to-avoid-getting-throttled-or-blocked-in-sharepoint-online#how-to-decorate-your-http-traffic-to-avoid-throttling
        $DestCtx.add_ExecutingWebRequest({
            param($Source, $EventArgs)
            $request = $EventArgs.WebRequestExecutor.WebRequest
            $request.UserAgent = "NONISV|PowerShell|TaxonomyMigrationApp/2.0"
        })

        ExecuteQueryWithRetry $Destctx
        return $Destctx 
    }
    else
    {
        $SrcCtx = New-Object Microsoft.SharePoint.Client.ClientContext($SiteUrl)
        $SecurePassword = ConvertTo-SecureString –String $Password –AsPlainText –force
        $Credentials = [System.Management.Automation.PSCredential]::new($Username,$SecurePassword)
        $SrcCtx.Credentials = $Credentials

        # Decorate our CSOM Calls to SPO to help with throttling
        # https://docs.microsoft.com/en-us/sharepoint/dev/general-development/how-to-avoid-getting-throttled-or-blocked-in-sharepoint-online#how-to-decorate-your-http-traffic-to-avoid-throttling
        $SrcCtx.add_ExecutingWebRequest({
            param($Source, $EventArgs)
            $request = $EventArgs.WebRequestExecutor.WebRequest
            $request.UserAgent = "NONISV|PowerShell|TaxonomyMigrationApp/2.0"
        }) 

        ExecuteQueryWithRetry $SrcCtx
        return $SrcCtx
    }  
}

function WalkSourceTerm
{
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true)][Microsoft.SharePoint.Client.Taxonomy.Term]$term, #srcTerm
        [Parameter(Mandatory=$true)][Microsoft.SharePoint.Client.Taxonomy.TermSet]$termset, #DestTermSet
        [Parameter(Mandatory=$true)][Microsoft.SharePoint.Client.Taxonomy.TermGroup]$termgroup #DestTermGroup
    )
    $destSrcTerm = $null
    Write-Host "Entering 'WalkSourceTerm' Function:" -foreground Cyan
    $function = "WalkSourceTerm:"

    $SrcCtx.Load($term.Terms)
    ExecuteQueryWithRetry $SrcCtx

    Write-Host "$function Getting Term '$($term.Name)' from Destination Termset '$($termset.Name)'" -ForegroundColor Yellow
    [Microsoft.SharePoint.Client.Taxonomy.Term]$destSrcTerm = GetTerm -term $term -termset $termset
    Write-Host "$function Checking to see if Term '$($term.Name)' has any Child Terms" -ForegroundColor Yellow
    if($term.terms.Count -gt 0)
    {
        Write-Host "$function Term '$($term.Name)' has '$($term.terms.Count)' Child Terms" -ForegroundColor Yellow
        Write-Host "$function Walking All Child Terms" -ForegroundColor Yellow
        foreach($childTerm in $term.terms)
        {
            $SrcCtx.Load($childterm)
            ExecuteQueryWithRetry $SrcCtx

            $DestCtx.Load($termset)
            $DestCtx.Load($termgroup)
            ExecuteQueryWithRetry $DestCtx

            WalkSourceTerm -term $childTerm -termset $termset -termgroup $termgroup
        }
    }
    else
    {
        Write-Host "$function Term: '$($term.name)' does not have any child terms" -ForegroundColor Yellow
    }

    <#
    $childterm = $null
    $term = $null
    $termset = $null
    $termgroup = $null
    return
    #>
}

function GetTermStore
{
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true)][Microsoft.SharePoint.Client.ClientContext]$Ctx
    )

    $TaxonomySession = [Microsoft.SharePoint.Client.Taxonomy.TaxonomySession]::GetTaxonomySession($Ctx)

    $Ctx.Load($TaxonomySession)
    ExecuteQueryWithRetry $Ctx

    [Microsoft.SharePoint.Client.Taxonomy.TermStoreCollection]$TermStores = $TaxonomySession.TermStores

    $Ctx.Load($TermStores)
    ExecuteQueryWithRetry $Ctx

    [Microsoft.SharePoint.Client.Taxonomy.TermStore]$TermStore = $TermStores[0]

    $Ctx.Load($TermStore)
    ExecuteQueryWithRetry $Ctx

    Write-Host "Retrieved Source Term Store: '$($TermStore.Name)'" -ForegroundColor Yellow

    return $TermStore
}

function GetTerm
{
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true)][Microsoft.SharePoint.Client.Taxonomy.Term]$term, #srcTerm
        [Parameter(Mandatory=$true)][Microsoft.SharePoint.Client.Taxonomy.TermSet]$termset #DestTermSet
        #[Parameter(Mandatory=$false)][Microsoft.SharePoint.Client.Taxonomy.TermGroup]$termsetGroup #DestTermSet Group
    )
    Write-Host "Entering 'GetTerm' Function:" -foreground Cyan
    $function = "GetTerm:"
    [boolean]$syncterm = $false

    $termset.refreshload()
    ExecuteQueryWithRetry $DestCtx

    $DestCtx.Load($termset.Group)
    ExecuteQueryWithRetry $DestCtx

    Write-Host "$function Getting all destination TermSet Terms for TermSet: '$($termset.Name)'" -ForegroundColor Yellow
    # Get all destintation termset terms
    [Microsoft.SharePoint.Client.Taxonomy.TermCollection]$trms = $termset.GetAllTerms() 
    
    $DestCtx.Load($trms)
    ExecuteQueryWithRetry $DestCtx
    
    # First Check to see if the Destination TermSet has any terms
    # And see if our term exists in the termset by ID, if it does return it, if it doesn't attempt to create it
    Write-Host "$function Checking to see if Destination TermSet: '$($termset.Name)' has any existing terms" -ForegroundColor Yellow
    Write-Host "$function Destination TermSet: '$($termset.Name)' has '$($trms.Count)' terms" -ForegroundColor Yellow
    Write-Host "$function Checking to see if term: '$($term.Name)' exists in destination Termset: '$($termset.Name)'" -ForegroundColor Yellow
    
    if(($trms.Count -gt 0) -and ($trms | ?{$_.Id -eq $term.Id.ToString()}))
    {
        [Microsoft.SharePoint.Client.Taxonomy.Term]$t = $trms | ?{$_.Id -eq $term.Id.ToString()}
        
        $DestCtx.Load($t)
        ExecuteQueryWithRetry $DestCtx
        
        Write-Host "$function Term: '$($t.Name)' already exists in TermSet: '$($termset.Name)'" -ForegroundColor Yellow
    }
    else
    {
        # Create Term in DestTermGroup/DestTermSet
        Write-Host "$function Term: '$($term.Name)' does not exist in TermSet: '$($termset.Name)'" -ForegroundColor Yellow
        Write-Host "$function Attempting to creating Term: '$($term.Name):$($term.Id)' in Destination TermSet: '$($termset.Name)'" -ForegroundColor Yellow
        [Microsoft.SharePoint.Client.Taxonomy.Term]$t = CreateTerm -term $term -termset $termset -termgroup $termset.Group
        $syncterm = $true
    }

    if(($syncterm) -and (![string]::IsNullOrEmpty($t.Name)))
    {
        Write-Host "$function Syncing Destination Term: '$($t.Name)' with Source Term '$($term.Name)'" -ForegroundColor Yellow
        SyncTermInfo -destTerm $t -srcTerm $term
        
    }
    
    return $t
}

function CreateTerm
{
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true)][Microsoft.SharePoint.Client.Taxonomy.Term]$term, #SrcTerm
        [Parameter(Mandatory=$true)][Microsoft.SharePoint.Client.Taxonomy.TermSet]$termset, #DestTermSet
        [Parameter(Mandatory=$true)][Microsoft.SharePoint.Client.Taxonomy.TermGroup]$termgroup #DestTermGroup
    )
    Write-Host "Entering 'CreateTerm' Function:" -foreground Cyan
    $function = "CreateTerm:"
    Write-Host "$function Reloading Objects" -ForegroundColor Yellow
    
    $SrcCtx.Load($term.Parent)
    $SrcCtx.Load($term.SourceTerm)
    $SrcCtx.Load($term.SourceTerm.Terms)
    $SrcCtx.Load($term.SourceTerm.TermSet)
    $SrcCtx.Load($term.SourceTerm.TermSet.Group)
    ExecuteQueryWithRetry $SrcCtx

    $DestCtx.Load($termgroup.TermStore)
    ExecuteQueryWithRetry $DestCtx

    Write-Host "$function loaded objects: '$($term.Name)', '$($termset.Name)', '$($termgroup.Name)'" -ForegroundColor Green

    [Boolean]$isRoot = $term.IsRoot
    [Boolean]$isReused = $term.IsReused
    [Boolean]$isSourceTerm = $term.IsSourceTerm
    [Boolean]$isPinned = $term.IsPinned
    [Boolean]$isPinnedRoot = $term.IsPinnedRoot    
    Write-Host "$function Checking to see if the term is source and not reused, or not the source and resused/pinned" -ForegroundColor Yellow
    # Create Root Source Term under Parent TermSet
    if($isRoot -and $isSourceTerm)
    {
        Write-Host "$function Term: '$($term.Name)' is a root term and is a source term" -ForegroundColor Yellow
        Write-Host "$function Creating Term: '$($term.Name)' off Destination TermSet '$($termset.Name)'" -ForegroundColor Green
        [Microsoft.SharePoint.Client.Taxonomy.Term]$NT = $termset.CreateTerm($term.Name,$lcid,$term.Id)
        
        $DestCtx.Load($NT)
        ExecuteQueryWithRetry $DestCtx
        
        $DestTermStore.CommitAll()
        Start-Sleep -Seconds 2
        Write-Host "$function Created Term: '$($NT.Name)'" -ForegroundColor Green
        return $NT
    }
    # Create Non-Root Source Term under Parent Term
    elseif(!$isRoot -and $isSourceTerm)
    {
        Write-Host "$function Term: '$($term.Name)' is not a root term but it is a source term so we must loop through all parent terms" -ForegroundColor Yellow
        # Get Parent Term So we can create the term under the proper parent

        Write-Host "$function Getting parent Term: '$($term.Parent.Name)'" -ForegroundColor Yellow
        $termset.RefreshLoad()
        [Microsoft.SharePoint.Client.Taxonomy.Term]$pt = GetTerm -term $term.Parent -termset $termset
        
        Write-Host "$function Creating Term: '$($term.name)' under parent term: '$($pt.name)'" -ForegroundColor Green
        [Microsoft.SharePoint.Client.Taxonomy.Term]$nt = $pt.CreateTerm($term.Name,$lcid,$term.Id)
        
        $DestCtx.Load($nt)
        ExecuteQueryWithRetry $DestCtx

        $DestTermStore.CommitAll()
        Start-Sleep -Seconds 2
        Write-Host "$function Created Term: '$($nt.Name)'" -ForegroundColor Green
        return $nt
    }
    # Create Non-Source Reused Non-Pinned Term
    elseif(!$isSourceTerm -and !$isPinned) #This means it is reused but it is the root so we must reuse on the term set but we have to reuse from its source
    {
        Write-Host "$function Term is not a source term and it's not pinned. We must reuse this term" -ForegroundColor Yellow
        Write-Host "$function Getting the Term: '$($term.Name)' Source term, termset, and group" -ForegroundColor Yellow
        # Get the terms Source Terms term Group in Src Term Store
        [Microsoft.SharePoint.Client.Taxonomy.TermGroup]$grp = $term.SourceTerm.TermSet.Group #SrcTermStore SourceTerm TermSet Group

        Write-Host "$function Getting Destination Term Group '$($grp.Name)'" -ForegroundColor Yellow
        
        # Get the group from the destination term store based on Src TermStore Source Term termset group
        [Microsoft.SharePoint.Client.Taxonomy.TermGroup]$tg = GetTermGroup -group $grp -termStore $termgroup.TermStore # Get Destination Term Group
        
        # Get the terms source terms termset
        Write-Host "$function Getting the Term: '$($term.Name)' Source term's termset" -ForegroundColor Yellow
        [Microsoft.SharePoint.Client.Taxonomy.TermSet]$trmset = $term.SourceTerm.TermSet #SrcTermStore SourceTerm TermSet

        Write-Host "$function Getting Source TermSet '$($trmset.Name)' in Destination Term Group '$($tg.Name)'" -ForegroundColor Yellow
        [Microsoft.SharePoint.Client.Taxonomy.TermSet]$ts = GetTermSet -termset $trmset -group $tg #Src TermSet  Dest Group return Dest TermSet

        # Get the terms Source Term from the source termset
        Write-Host "$function Getting the Source Term: '$($term.Name)' Source term" -ForegroundColor Yellow
        [Microsoft.SharePoint.Client.Taxonomy.Term]$strm = $term.SourceTerm #SrcTerm Store Source TErm

        Write-Host "$function Getting the source Term: '$($strm.Name)' in destination termset '$($ts.Name)'" -ForegroundColor Yellow
        # Create/Get the reused Terms Source Term in Destination TermSet
        [Microsoft.SharePoint.Client.Taxonomy.Term]$st = GetTerm -term $strm -termset $ts

        # If Term is a root term create
        if($isRoot)
        {
            Write-Host "$function Source term: '$($term.Name)' is a root term. Reusing Term off Termset: '$($termset.Name)' in Term Group: '$($termgroup.Name)'" -ForegroundColor Green 
            [Microsoft.SharePoint.Client.Taxonomy.Term]$NewTerm = $termset.ReuseTerm($st, $false)
            
            $DestCtx.Load($NewTerm)
            ExecuteQueryWithRetry $DestCtx
            
            $DestTermStore.CommitAll()
            Start-Sleep -Seconds 2
            return $NewTerm
        }
        else
        {
            # Get Term Parent Term
            Write-Host "$function Term: '$($term.Name)' is not a root term" -ForegroundColor Yellow
            Write-Host "$function Getting Term: '$($term.Name)' parent term" -ForegroundColor Yellow
            [Microsoft.SharePoint.Client.Taxonomy.Term]$tp = $term.Parent
            
            $SrcCtx.Load($tp)
            ExecuteQueryWithRetry $SrcCtx

            Write-Host "$function Getting Destination Term parent: '$($tp.Name)' in Destination TermSet '$($termset.Name)'" -ForegroundColor Yellow
            # Get Parent Term in Destination TermSet
            [Microsoft.SharePoint.Client.Taxonomy.Term]$Srcparent = GetTerm -term $tp -termset $termset

            Write-Host "Creating Resused term: '$($term.Name)' under parent term: '$($srcparent.Name)'" -ForegroundColor Green
            [Microsoft.SharePoint.Client.Taxonomy.Term]$newst = $Srcparent.ReuseTerm($st, $false)
            
            $DestCtx.Load($newst)
            ExecuteQueryWithRetry $DestCtx

            $DestTermStore.CommitAll()
            Start-Sleep -Seconds 2
            return $newst       
        }
    }
    elseif($isPinned -and $isPinnedRoot) # We must make sure the source term and all child terms are created before we can pin
    {
        Write-Host "$function Term: '$($term.Name)' is Pinned and is the pinned root" -ForegroundColor Yellow
        Write-Host "$function Getting the Pinned Terms source TermSet" -ForegroundColor Yellow
        [Microsoft.SharePoint.Client.Taxonomy.TermSet]$PinSourceTermSet = $term.PinSourceTermSet
        
        $SrcCtx.Load($PinSourceTermSet)
        ExecuteQueryWithRetry $SrcCtx

        [Microsoft.SharePoint.Client.Taxonomy.TermGroup]$PinSourceGroup = $PinSourceTermSet.Group
        
        $SrcCtx.Load($PinSourceGroup)
        ExecuteQueryWithRetry $SrcCtx

        # Get Dest pinned Group
        Write-Host "$function Getting the Pinned Terms source TermSet TermGroup" -ForegroundColor Yellow
        [Microsoft.SharePoint.Client.Taxonomy.TermGroup]$tg = GetTermGroup -group $PinSourceGroup -termStore $termgroup.TermStore
        
        $DestCtx.Load($tg.TermSets)
        ExecuteQueryWithRetry $DestCtx
        
        [Microsoft.SharePoint.Client.Taxonomy.TermSetCollection]$tgts = $tg.TermSets

        # Get Dest pinned TermSet
        if(!($tgts | ?{$_.Id -eq $PinSourceTermSet.Id}))
        {
            Write-Host "$function Destination Pinned TermSet: '$($PinSourceTermSet.Name)' does not exist. Creating it now" -ForegroundColor Yellow
            [Microsoft.SharePoint.Client.Taxonomy.TermSet]$ts = GetTermSet -termset $PinSourceTermSet -group $tg
        }
        else       
        {
            Write-Host "$function Source Pinned TermSet '$($PinSourceTermSet.Name)' already exists in the destination TermStore" -ForegroundColor Yellow
            [Microsoft.SharePoint.Client.Taxonomy.TermSet]$ts = $tg.TermSets | ?{$_.Id -eq $PinSourceTermSet.Id}
        }
        # Get Source Term in Dest TermSet
        Write-Host "$function Getting term: '$($term.Name)' Source Term: '$($term.SourceTerm.Name)' in destination termset: '$($ts.Name)'" -ForegroundColor Yellow
        [Microsoft.SharePoint.Client.Taxonomy.Term]$st = GetTerm -term $term.SourceTerm -termset $ts #Destination Term Returned

        # Recursively make sure the pinned terms source term has all their child terms created before we pin the term
        if($term.SourceTerm.terms.count -gt 0)
        {
            Write-Host "$function Source Term: '$($term.SourceTerm.Name)' has '$($term.SourceTerm.terms.count)' child terms" -ForegroundColor Yellow
            foreach($trm in $term.SourceTerm.terms)
            {
                $SrcCtx.Load($trm)
                ExecuteQueryWithRetry $SrcCtx                
                
                $DestCtx.Load($ts)
                $DestCtx.Load($tg)
                ExecuteQueryWithRetry $DestCtx
                
                Write-Host "Making sure all the Child Terms of the Source term '$($trm.Name):$($trm.Id)' exist before we pin the term '$($term.Name)'" -ForegroundColor Yellow
                WalkSourceTerm -term $trm -termset $ts -termgroup $tg
                
            }
            if(!$isRoot)
            {
                Write-Host "Term: '$($term.Name)' is not a root term" -ForegroundColor Yellow
                Write-Host "Getting Term: '$($term.Name)' source term's parent term" -ForegroundColor Yellow
                [Microsoft.SharePoint.Client.Taxonomy.Term]$Srcparent = GetTerm -term $term.Parent -termset $termset

                Write-Host "Pinning Term: '$($term.Name)' on parent term: '$($Srcparent.Name)'" -ForegroundColor Green
                [Microsoft.SharePoint.Client.Taxonomy.Term]$newst = $Srcparent.ReuseTermWithPinning($st)
                
                #Load-CSOMObject -context $Destctx -object ([REF]$newst) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false
                $DestCtx.Load($newst)
                ExecuteQueryWithRetry $DestCtx
                
                $DestTermStore.CommitAll()
                Start-Sleep -Seconds 2
                return $newst     
            }
            else
            {
                Write-Host "Term: '$($term.Name)' is a root term." -ForegroundColor Yellow
                Write-Host "Pinning Term: '$($term.Name)' on termset: '$($termset.Name)'" -ForegroundColor Green
                [Microsoft.SharePoint.Client.Taxonomy.Term]$NewTerm = $termset.ReuseTermWithPinning($st)
                
                #Load-CSOMObject -context $Destctx -object ([REF]$NewTerm) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false
                $DestCtx.Load($NewTerm)
                ExecuteQueryWithRetry $DestCtx
                
                $DestTermStore.CommitAll()
                Start-Sleep -Seconds 2
                return $NewTerm
            }   
        }
        else
        {
            if(!$isRoot)
            {
                Write-Host "Term: '$($term.Name)' is not a root term." -ForegroundColor Yellow
                Write-Host "Getting Term: '$($term.Name)' source term's parent term" -ForegroundColor Yellow
                [Microsoft.SharePoint.Client.Taxonomy.Term]$Srcparent = GetTerm -term $term.Parent -termset $termset

                Write-Host "Pinning Term: '$($term.Name)' on parent term: '$($Srcparent.Name)'" -ForegroundColor Green
                [Microsoft.SharePoint.Client.Taxonomy.Term]$newst = $Srcparent.ReuseTermWithPinning($st)
                
                #Load-CSOMObject -context $Destctx -object ([REF]$newst) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false
                $DestCtx.Load($newst)
                ExecuteQueryWithRetry $DestCtx
                
                $DestTermStore.CommitAll()
                Start-Sleep -Seconds 2
                return $newst     
            }
            else
            {
                Write-Host "Term: '$($term.Name)' is a root term" -ForegroundColor Yellow
                Write-Host "Pinning Term: '$($term.Name)' on termset: '$($termset.Name)'" -ForegroundColor Green
                [Microsoft.SharePoint.Client.Taxonomy.Term]$NewTerm = $termset.ReuseTermWithPinning($st)
                
                #Load-CSOMObject -context $Destctx -object ([REF]$NewTerm) -numSecBetweenRetries 5 -numRetries 5 -throwExceptionOnError:$false
                $DestCtx.Load($NewTerm)
                ExecuteQueryWithRetry $DestCtx
                
                $DestTermStore.CommitAll()
                Start-Sleep -Seconds 2
                return $NewTerm
            }   
 
        }
        elseif($isPinned -and !$isPinnedRoot) 
        {
            # This term is pinned but it's not the root of the pin we must skip this as we must pin term and all child terms
            Write-Host "Term: '$($term.name)' is pinned but it's not the pinned root term" -ForegroundColor Cyan
            write-Host "Getting Destination Term so we can Sync it" -ForegroundColor Yellow
            [Microsoft.SharePoint.Client.Taxonomy.Term]$t = GetTerm -term $term -termset $termset
            SyncTermInfo -destTerm $t -srcTerm $term
            return 
        }
    }
}

function GetTermGroup
{
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true)][Microsoft.SharePoint.Client.Taxonomy.TermStore]$termStore, #DestTermStore
        [Parameter(Mandatory=$true)][Microsoft.SharePoint.Client.Taxonomy.TermGroup]$group #SrcGroup
    )
    Write-Host "Entering 'GetTermGroup' Function:" -foreground Cyan
    [boolean]$syncgroup = $false
    Write-Host "Reloading Term Group Objects" -ForegroundColor Yellow
    
    $group.RefreshLoad()
    ExecuteQueryWithRetry $SrcCtx

    $termStore.RefreshLoad()
    ExecuteQueryWithRetry $DestCtx
    
    $DestCtx.Load($termStore.Groups)
    ExecuteQueryWithRetry $DestCtx
    
    if($termStore.groups.id.Guid.Contains($group.id.ToString()))
    {
        Write-Host "Term Group: '$($group.Name)' already exists in the destination term store." -ForegroundColor Yellow
        [Microsoft.SharePoint.Client.Taxonomy.TermGroup]$g = $termStore.groups | ?{$_.Id -eq $group.Id}
        
        $DestCtx.Load($g)
        ExecuteQueryWithRetry $DestCtx
   
    }
    else
    {
        Write-Host "Term Group: '$($group.Name)' does not exist in the destination term store." -ForegroundColor Yellow
        [Microsoft.SharePoint.Client.Taxonomy.TermGroup]$g = CreateTermGroup -termStore $termStore -group $group
        $syncgroup = $true
    }

    if($syncgroup)
    {
        Write-Host "Syncing Destination Term Group: '$($g.Name)' with Source Term Group '$($group.Name)'" -ForegroundColor Yellow
        SyncTermGroupInfo -destTermGroup $g -srcTermGroup $group
    }
    return $g
}

function CreateTermGroup
{
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$false)][Microsoft.SharePoint.Client.Taxonomy.TermStore]$termStore, #DestTermStore
        [Parameter(Mandatory=$true)][Microsoft.SharePoint.Client.Taxonomy.TermGroup]$group #SrcGroup
    )
        Write-Host "Entering 'CreateTermGroup' Function:" -foreground Cyan
        $function = "CreateTermGroup:"
        Write-Host " $function Creating Term Group '$($group.Name)' in Destination TermStore" -ForegroundColor Yellow
        [Microsoft.SharePoint.Client.Taxonomy.TermGroup]$createdGroup = $termStore.CreateGroup($group.name, $group.id)
        
        $DestCtx.Load($createdGroup)
        ExecuteQueryWithRetry $DestCtx
        
        $termStore.CommitAll()
        Start-Sleep -Seconds 2
        return $createdGroup
}

function GetTermSet
{
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true)][Microsoft.SharePoint.Client.Taxonomy.TermGroup]$group, #DestGroup
        [Parameter(Mandatory=$true)][Microsoft.SharePoint.Client.Taxonomy.TermSet]$termset #SrcTermSet
    )
        Write-Host "Entering 'GetTermSet' Function:" -foreground Cyan
        $function = "GetTermSet:"
        [boolean]$SyncTermSet = $false
        Write-Host "$function Getting Group: '$($group.Name)' Termsets" -ForegroundColor Yellow
        
        $group.refreshload()
        $DestCtx.Load($group.TermSets)
        ExecuteQueryWithRetry $DestCtx
        
        Write-Host "$function Checking for Termset: '$($termset.Name)' in Destination group '$($group.Name)' Termsets" -ForegroundColor Yellow
        if(($group.TermSets.Count -gt 0) -and ($group.TermSets.Name.Contains($termset.Name)))
        {
            Write-Host "$function Termset: '$($termset.Name)' already exists in destination Term Group: '$($group.Name)'" -ForegroundColor Yellow
            [Microsoft.SharePoint.Client.Taxonomy.TermSet]$ts = $group.TermSets | ?{$_.Name -eq "$($termset.Name)"}
            
            $DestCtx.Load($ts)
            ExecuteQueryWithRetry $DestCtx
        
        }
        else
        {
            Write-Host "$function Termset: '$($termset.Name)' does not exist in Destination Term Group: '$($group.Name)' so we will attempt to create it" -ForegroundColor Yellow
            [Microsoft.SharePoint.Client.Taxonomy.TermSet]$ts = CreateTermSet -termset $termset -group $group
            $syncTermSet = $true
        }
        
        if($syncTermSet)
        {
            Write-Host "$function Syncing Destination Term Set: '$($ts.Name)' with Source Term Group '$($termset.Name)'" -ForegroundColor Yellow
            SyncTermSetInfo -destTermSet $ts -srcTermSet $termset
        }
        return $ts
}

function CreateTermSet
{
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true)]$termset, #SrcTermSet
        [Parameter(Mandatory=$true)]$group #DestGroup
    )
    Write-Host "Entering 'CreateTermSet' Function:" -foreground Cyan
    $function = "CreateTermSet:"

    Write-Host "$function Creating Termset: '$($termset.Name):$($termset.Id)' in destination term group: '$($group.Name)'" -ForegroundColor Yellow
    [Microsoft.SharePoint.Client.Taxonomy.TermSet]$tset = $group.CreateTermSet($termset.Name,$termset.Id,$lcid)
    
    $DestCtx.Load($tset)
    ExecuteQueryWithRetry $DestCtx
    
    $destTermStore.CommitAll()
    Start-Sleep -Seconds 2
    return $tset
}

function SyncTermInfo
{
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true)][Microsoft.SharePoint.Client.Taxonomy.Term]$destTerm,
        [Parameter(Mandatory=$true)][Microsoft.SharePoint.Client.Taxonomy.Term]$srcTerm
    )
    Write-Host "Entering 'SyncTermInfo' Function:" -foreground Cyan
    $function = "SyncTermInfo:"

    $ErrorActionPreference = "Continue"
    [Boolean]$needsUpdate = $false
	
    #region Sync properties regardless of term type. 
    
    # They can exist regardless of whether or not the term was re-used and/or Pinned
	Write-Host "$function Syncing term properties regardless of term type."
    
    # Add any local properties that are needed
    if($srcTerm.LocalCustomProperties.Count -gt 0)
    {
		if($srcTerm.LocalCustomProperties.Key.Count -gt 0)
		{
			Write-Host "$function Processing local custom properties for ""$($srcTerm.Name)""" -forground yellow
			foreach($srcProperty in $srcTerm.LocalCustomProperties.Keys)
			{
				if($destTerm.LocalCustomProperties[$srcProperty] -ne $srcTerm.LocalCustomProperties[$srcProperty])
				{
					Write-Host "$function Updating the Local Custom Property ""$srcProperty"" for ""$($destTerm.Name)"""
					$destTerm.SetLocalCustomProperty($srcProperty, $srcTerm.LocalCustomProperties[$srcProperty])
					$needsUpdate = $true       
				}
			}
		}
    }

    if($destTerm.IsAvailableForTagging -ne $srcTerm.IsAvailableForTagging) 
    { 
        Write-Host "$function Found discrepancy in Is Available For Tagging. Updating it." -ForegroundColor Yellow
        $destTerm.IsAvailableForTagging = $srcTerm.IsAvailableForTagging 
		$needsUpdate = $true       
    }

    # Deprecate the term if needed
    if($destTerm.IsDeprecated -ne $srcTerm.IsDeprecated)
    {
        Write-Host "$function Found discrepancy in Is Deprecated. Updating it." -ForegroundColor Yellow
        $destTerm.Deprecate($srcTerm.IsDeprecated)
        $needsUpdate = $true       
    }
    
    if($needsUpdate)
    {
        Write-Host "$function Done processing term ""$($srcTerm.Name)"". Committing all changes." -ForegroundColor Yellow
        $DestTermStore.CommitAll()
        Start-Sleep -Seconds 2
    }
	#endregion

	#region Sync Term properties per term type
	Write-Host "$function Syncing term properties per term type." -ForegroundColor Yellow
	# Source Terms
	if($srcTerm.IsSourceTerm -and ($srcTerm.IsReused -or !($srcTerm.IsReused)))
	{
        Write-Host "Loading Destination Term Labels" -ForegroundColor Yellow
        $DestCtx.Load($destTerm.Labels)
        ExecuteQueryWithRetry $DestCtx
    
        Write-Host "Loading Source Term Labels" -ForegroundColor Yellow
        $SrcCtx.Load($srcTerm.Labels)
        ExecuteQueryWithRetry $SrcCtx
		<#
        if($destTerm.Owner -ne $srcTerm.Owner)
		{
			
			Write-Host "Found discrepancy in the Owner. Updating it." -ForegroundColor Yellow
			$srcOwner = $srcTerm.Owner
			$prefix = $srcOwner.Replace("w","f")
			$membership = $prefix.Replace("campperson\","membership|")
			$newOwner = $membership + $UPN
			$destTerm.Owner = $newOwner
			$needsUpdate = $true
		}
        #>
        
		if($destTerm.Description -ne $srcTerm.Description) 
		{ 
			Write-Host "$function Found discrepancy in the Description. Updating it." -ForegroundColor Yellow
			$destTerm.SetDescription($srcTerm.Description, $lcid) 
			$needsUpdate = $true       
		}

		if($destTerm.Labels.AreItemsAvailable -and $srcTerm.Labels.AreItemsAvailable)
		{
			# Add any labels needed and, if it already exists, set the default label appropriately
			foreach($srcLabel in $srcTerm.Labels)
			{
				[Microsoft.SharePoint.Client.Taxonomy.Label]$destLabel = $destTerm.Labels | Where-object {$_.Value -eq $srcLabel.Value -and $_.Language -eq $srcLabel.Language}
				if($destLabel -eq $null)
				{
                    Write-Host "$function Adding the Label '$($srcLabel.Value)'" -ForegroundColor Yellow
					$destTerm.CreateLabel($srcLabel.Value, $srcLabel.Language, $srcLabel.IsDefaultForLanguage) | Out-Null
					$needsUpdate = $true       
				}
				else
				{
					if($srcLabel.IsDefaultForLanguage -ne $destLabel.IsDefaultForLanguage)
					{
						Write-Host "$function Updating the Default Label" -ForegroundColor Yellow
						$destLabel.IsDefaultForLanguage = $srcLabel.IsDefaultForLanguage
						$needsUpdate = $true       
					}
				}
			}   
		}                
		else
		{
			Write-Host "$function Source or destination term labels do not exist or have not yet been initialized" -ForegroundColor Yellow
		}

		 # Sync custom properties
		if($srcTerm.CustomProperties.Count -gt 0)
		{
            Write-Host "$function Processing custom properties for ""$($srcTerm.Name)""" -ForegroundColor Yellow
			foreach($srcProperty in $srcTerm.CustomProperties.Keys)
			{
				if($destTerm.CustomProperties[$srcProperty] -ne $srcTerm.CustomProperties[$srcProperty])
				{
                    Write-Host "$function Updating the Custom Property ""$srcProperty""" -ForegroundColor Yellow
					$destTerm.SetCustomProperty($srcProperty, $srcTerm.CustomProperties[$srcProperty])
					$needsUpdate = $true       
				}
			}
		}

		if($destTerm.CustomSortOrder -ne $srcTerm.CustomSortOrder) 
        { 
            Write-Host "$function Found discrepancy in the Custom Sort Order. Updating it." -ForegroundColor Yellow
            $destTerm.CustomSortOrder = $srcTerm.CustomSortOrder 
            $needsUpdate = $true       
        }
	}

	# Reused Terms that aren't source terms and pinned terms that are the pinned root
	if(($srcTerm.IsReused -and !($srcTerm.IsSourceTerm)) -or ($srcTerm.IsPinned -and $srcTerm.IsPinnedRoot))
	{
		if($destTerm.CustomSortOrder -ne $srcTerm.CustomSortOrder) 
        { 
            Write-Host "$function Found discrepancy in the Custom Sort Order. Updating it." -ForegroundColor Yellow
            $destTerm.CustomSortOrder = $srcTerm.CustomSortOrder 
            $needsUpdate = $true       
        }
	}

	if($needsUpdate)
    {
        Write-Host "$function Done processing term ""$($srcTerm.Name)"" properties. Committing all changes." -ForegroundColor Yellow
        $DestTermStore.CommitAll()
        Start-Sleep -Seconds 2
    }
	#endregion
    Write-Host "$function Done syncing term info." -ForegroundColor Green
}

function SyncTermSetInfo
{
	[CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true)][Microsoft.SharePoint.Client.Taxonomy.TermSet]$destTermSet,
        [Parameter(Mandatory=$true)][Microsoft.SharePoint.Client.Taxonomy.TermSet]$srcTermSet
    )
    #Start-Sleep -Seconds 3
    Write-Host "Entering 'SyncTermSetInfo' Function:" -foreground Cyan
	[Boolean]$needsUpdate = $false 

    <#
	#Set the contact and Stake Holders
    Write-Host "Adding Termset Contact and Stakeholders if they exist"

	if($destTermSet.Contact -ne $srcTermSet.Contact)
	{
		Write-Host "Found discrepency in TermSet Contact. Updating object to: ""$($srcTermSet.Contact)""." -ForegroundColor Yellow
		$destTermSet.Contact = $srcTermSet.Contact
		$needsUpdate = $true
	}

    if($destTermSet.Owner -ne $srcTermSet.Owner)
	{
        $srcOwner = $srcTermSet.Owner
        $prefix = $srcOwner.Replace("w","f")
        $membership = $prefix.Replace("campperson\","membership|")
        $newOwner = $membership + $UPN
		Write-Host "Found discrepency in TermSet Owner. Updating object owner to: ""$($newOwner)""." -ForegroundColor Yellow
		$destTermSet.Owner = $newOwner
		$needsUpdate = $true
	}

	if($srcTermSet.Stakeholders.count -gt 0)
	{
		if($destTermSet.Stakeholders -ne $srcTermSet.Stakeholders)
		{
			$Stakeholdersarray = @()
			$Stakeholdersarray += $srcTermSet.Stakeholders
			foreach($item in $Stakeholdersarray)
			{
				$prefix = $item.Replace("w","f")
				$membership = $prefix.Replace("campperson\","membership|")
				$newStakeHolder = $membership + $UPN
				$DestTermSet.AddStakeholder($newStakeHolder) 
				$needsUpdate = $true
			}
		}
	}
    #>

    if($destTermSet.CustomSortOrder -ne $srcTermSet.CustomSortOrder)
    {
        Write-Host "$function Found discrepancy in the Custom Sort Order. Will update." -ForegroundColor Yellow
        $destTermSet.CustomSortOrder = $srcTermSet.CustomSortOrder
        $needsUpdate = $true
    }
    
    if($destTermSet.Description -ne $srcTermSet.Description)
    {
        Write-Host "$function Found discrepancy in the Description. Will update." -ForegroundColor Yellow
        $destTermSet.Description = $srcTermSet.Description
        $needsUpdate = $true
    }

    if($destTermSet.IsAvailableForTagging -ne $srcTermSet.IsAvailableForTagging)
    {
        Write-Host "$function Found discrepancy in Available for Tagging. Will update."  -ForegroundColor Yellow
        $destTermSet.IsAvailableForTagging = $srcTermSet.IsAvailableForTagging
        $needsUpdate = $true
    }
    
    if($destTermSet.IsOpenForTermCreation -ne $srcTermSet.IsOpenForTermCreation)
    {
        Write-Host "$function Found discrepancy in the Submission Policy. Will update."  -ForegroundColor Yellow
        $destTermSet.IsOpenForTermCreation = $srcTermSet.IsOpenForTermCreation
        $needsUpdate = $true
    }

    # Sync custom properties
    if($srcTermSet.CustomProperties.Count -gt 0)
    {
        Write-Host "$function Examining Custom Properties on ""$($srcTermSet.Name)""" -ForegroundColor Yellow
        foreach($srcProperty in $srcTermSet.CustomProperties.Keys)
        {
            if($destTermSet.CustomProperties[$srcProperty] -ne $srcTermSet.CustomProperties[$srcProperty])
            {
                Write-Host "$function Found discrepancy in Custom Property ""$($srcProperty)"". Will update." -ForegroundColor Yellow
                $destTermSet.SetCustomProperty($srcProperty, $srcTermSet.CustomProperties[$srcProperty])
                $needsUpdate = $true
            }
        }
    }
	# Write all the changes to this point
    if($needsUpdate)
    {
        Write-Host "$function Updating the term set ""$($srcTermSet.Name)"" and committing all changes" -ForegroundColor Yellow     
        $DestTermStore.CommitAll()

        Start-Sleep -Seconds 2
        Write-Host "Done!" -ForegroundColor Green
    }
    else
    {
        Write-Host "$function No property updates needed for the term set ""$($srcTermSet.Name)"""  -ForegroundColor Green
    }
}

function SyncTermGroupInfo
{
	[CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true)][Microsoft.SharePoint.Client.Taxonomy.TermGroup]$destTermGroup,
        [Parameter(Mandatory=$true)][Microsoft.SharePoint.Client.Taxonomy.TermGroup]$srcTermGroup
    )
    Write-Host "Entering 'SyncTermGroupInfo' Function:" -foreground Cyan
    $function = "SyncTermGroupInfo"
    #Start-Sleep 1

	[Boolean]$needsUpdate = $false

    # Synchronize term group properties
    if($srcTermGroup.Description -ne $destTermGroup.Description)
    {
        Write-Host "$function Found term group description discrepancy. Updating." -ForegroundColor Yellow
        $destTermGroup.Description = $srcTermGroup.Description
        $needsUpdate = $true
    }

	<#if($srcTermGroup.ContributorPrincipalNames.count -gt 0)
	{
		if($destTermGroup.ContributorPrincipalNames -ne $srcTermGroup.ContributorPrincipalNames)
		{
			Write-Host "Found term group Contributor discrepancy. Updating."
			$PrincipalNamesarray = @()
			$PrincipalNamesarray  += $srcTermGroup.ContributorPrincipalNames
			foreach($item in $PrincipalNamesarray)
			{
				$prefix = $item.Replace("w","f")
				$membership = $prefix.Replace("teckcominco\","membership|")
				$newContributor = $membership + $UPN
				$destTermGroup.AddContributor($newContributor) 
				$needsUpdate = $true  
			}
			$needsUpdate = $true
		}	
	}

	if($srcTermGroup.GroupManagerPrincipalNames.count -gt 0)
	{
		if($destTermGroup.GroupManagerPrincipalNames -ne $srcTermGroup.GroupManagerPrincipalNames)
		{
			Write-Host "Found term group description discrepancy. Updating."
			$GroupManagerArray = @()
			$GroupManagerArray += $srcTermGroup.GroupManagerPrincipalNames
			foreach($item in $PrincipalNamesarray)
			{
				$prefix = $item.Replace("w","f")
				$membership = $prefix.Replace("teckcominco\","membership|")
				$newManager = $membership + $UPN 
				$destTermGroup.AddGroupManager($newManager)
				$needsUpdate = $true  
			}
			$needsUpdate = $true
		}	
	}
	#>

	if($needsUpdate)
    {
        Write-Host "$function Updating the term Group ""$($srcTermGroup.Name)"" and committing all changes" -ForegroundColor Yellow
        $DestTermStore.CommitAll()
        Start-Sleep -Seconds 2
        Write-Host "$function Done!" -ForegroundColor Green
    }
    else
    {
        Write-Host "$function No property updates needed for the term group ""$($srcTermGroup.Name)""" -ForegroundColor Green
    }
}

function ExecuteQueryWithRetry2
{
    [CmdletBinding()]
    Param
    (
        [Parameter(Mandatory=$true)][Microsoft.SharePoint.Client.ClientRuntimeContext]$context,
        #[Parameter(Mandatory=$true)][System.Object][REF]$object,        # We need to type as a generic Object since anything can be here. Found that you need to do it by Reference or else the type on the returned object may not match the passed-in type.
        [Parameter(Mandatory=$false)][int]$numRetries = 5,
        [Parameter(Mandatory=$false)][int]$numSecBetweenRetries = 5,
        [Parameter(Mandatory=$false)][Boolean]$throwExceptionOnError = $false
    )

    #Write-Host "Loading object from SharePoint using CSOM..."
    $ErrorActionPreference = "SilentlyContinue"    # We will capture the error and report it ourselves.

    [int]$retries = 0
    [boolean]$success = $false
    [string]$errorMessage = $null
    do
    {
        if($retries -gt 0)
        {
            Write-Host "Retrying ($retries of $numRetries) after a $($numSecBetweenRetries*$retries) second pause..."
            Start-Sleep -s $($numSecBetweenRetries*$retries) 
        }
        
        try
        {
            $retryCount = 3
            $attempts = 0
            while ($attempts -lt $retryCount)
            {
                try
                {
                    $context.ExecuteQuery()
                    return
                }
                catch [System.Net.WebException]
                {
                    $response = [System.Net.HttpWebResponse]$error[0].Exception.InnerException.Response
                    # Can append ?Test429=True to force throttle
                    if($response -ne $null -and ($response.StatusCode -eq 429 -or $response.StatusCode -eq [System.Net.HttpStatusCode]::ServiceUnavailable))
                    { 
                        $retryAfter = $response.GetResponseHeader("Retry-After")
                        Write-Warning "CSOM Call throttled. Sleeping $retryAfter"
                        Write-Host "CSOM Call throttled. Sleeping $retryAfter" -ForegroundColor Red
                        Start-Sleep -Seconds $retryAfter
                        $attempts++
                    }
                    else
                    {
                        throw
                    }
                }
            }

            if($retries -gt 0)
            {
                Write-Host "`tSuccess on retry $retries"
            }

            $success = $true
        }
        catch
        {
            # Capture the first error message for reporting later (if needed)
            if( [string]::IsNullOrEmpty($errorMessage) ) { $errorMessage = $_.Exception.Message }
            Write-Host "`t`tError loading object! Error: '$($_.Exception.Message)'" -ForegroundColor Red
            $retries++ 
        }
    } 
    while (!$success -and $retries -le $numRetries)      # Keep looping until we have success or have run out of retries
    
    if(!$success)
    {
        Write-Host "`tGenerating failure response" -ForegroundColor Red

        Write-Host "Error loading object! Error message: $errorMessage" -ForegroundColor Red

        if($throwExceptionOnError)
        {
            Write-Debug "`t`tThrowing terminating error"
            $errorMsg = "Unable to execute CSOM query on object of type $($object.GetType()) on client connection to ""$($context.Url)"". Error message: $errorMessage"
            throw $errorMsg
        }
    }
}

function ExecuteQueryWithRetry
{
    param(
        [Microsoft.SharePoint.Client.ClientContext]$context,
        [int]$retryCount = 3,
        [int]$numSecBetweenRetries = 5
    )

    [boolean]$success = $false
    [boolean]$retryheader = $false
    [int]$attempts = 0
    [string]$errorMessage = $null


    while (!$success -and $attempts -lt $retryCount)
    {
        # Initiate Sleep between retry attempts based on retry after header or 5 sec increments
        # Implement the above if it's not the first attempt
        if($attempts -gt 0)
        {
            if($retryheader)
            {
                Write-Warning "CSOM Call throttled. Sleeping $retryAfter"
                Start-Sleep -Seconds $retryAfter
            }
            else
            {
                Write-Host "Retrying ($retries of $numRetries) after a $($numSecBetweenRetries*$retries) second pause..."
                Start-Sleep -s $($numSecBetweenRetries*$attempts) 
            }
        }

        try
        {
            $context.ExecuteQuery()
            $success = $true
            return
        }
        catch [System.Net.WebException]
        {
            $response = [System.Net.HttpWebResponse]$error[0].Exception.InnerException.Response
            # Can append ?Test429=True to force throttle
            if($response -ne $null -and ($response.StatusCode -eq 429 -or $response.StatusCode -eq [System.Net.HttpStatusCode]::ServiceUnavailable))
            { 
                $retryAfter = $response.GetResponseHeader("Retry-After")
                Write-Warning "CSOM Call throttled. Sleeping $retryAfter"
                Start-Sleep -Seconds $retryAfter
                $attempts++
                $retryheader = $true
            }
            else
            {
                if([string]::IsNullOrEmpty($errorMessage)) 
                {
                    $errorMessage = $_.Exception.Message 
                }
                Write-Host "`t`tError loading object! Error: '$($_.Exception.Message)'" -ForegroundColor Red
                $attempts++
            }
        }
    }
    Write-Error "Maximum retry attempts $retryCount, have been attempted."
}
#endregion

#region main
[Int32]$lcid = (Get-Culture).LCID

# Get the source term store


foreach($GroupName in $GroupList)
{
    Write-Host "Getting the client contexts" -ForegroundColor Yellow
    [Microsoft.SharePoint.Client.ClientContext]$SrcCtx = GetContext -SiteUrl $SrcSiteUrl -UserName $SrcUsername -Password $SrcPassword
    [Microsoft.SharePoint.Client.ClientContext]$DestCtx = GetContext -SiteUrl $SPOSiteUrl -UserName $SPOUsername -Password $SPOPassword -IsSPO 

    Write-Host "Getting the term stores" -ForegroundColor Yellow
    [Microsoft.SharePoint.Client.Taxonomy.TermStore]$DestTermStore = GetTermStore -Ctx $DestCtx
    [Microsoft.SharePoint.Client.Taxonomy.TermStore]$SrcTermStore = GetTermStore -Ctx $SrcCtx
    
    $SrcCtx.Load($SrcTermStore.Groups)
    ExecuteQueryWithRetry $SrcCtx

    # Get Source Term Group
    Write-Host "Getting the Source Term Group $GroupName" -ForegroundColor Yellow
    [Microsoft.SharePoint.Client.Taxonomy.TermGroup]$SrcGroup = $SrcTermStore.Groups | ?{$_.Name -eq $GroupName}
    
    $SrcCtx.Load($SrcGroup)
    $SrcCtx.Load($SrcGroup.TermSets)
    ExecuteQueryWithRetry $SrcCtx   
    
    Write-Host "Getting Destination Term Group: '$($SrcGroup.Name)'" -ForegroundColor Yellow
    [Microsoft.SharePoint.Client.Taxonomy.TermGroup]$DestGroup = GetTermGroup -termStore $DestTermStore -group $SrcGroup

    Write-Host "Looping through all termsets in Source Group: '$($SrcGroup.Name)'" -ForegroundColor Yellow
        
        
        
        $srcGroup.TermSets | ForEach-Object { Write-Host "Getting Source and Destination Termset: '$($_.Name)'" -ForegroundColor Yellow
        [Microsoft.SharePoint.Client.Taxonomy.TermSet]$DestTermSet = GetTermSet -group $DestGroup -termset $_

        Write-Host "Getting Source Termset: '$($_.Name)' Terms" -ForegroundColor Yellow
        #[Microsoft.SharePoint.Client.Taxonomy.TermCollection]$SrcTerms = $SrcTermSet.Terms
            
        $SrcCtx.Load($_)
        ExecuteQueryWithRetry $SrcCtx

        #Check to see if we are missing terms by term count and if so start looping through termset terms, otherwise skip to next termset

        [Microsoft.SharePoint.Client.Taxonomy.TermCollection]$srcTermSetTerms = $_.GetAllTerms()
        $SrcCtx.Load($_.Terms)
        $SrcCtx.Load($srcTermSetTerms)
        ExecuteQueryWithRetry $SrcCtx

        [Microsoft.SharePoint.Client.Taxonomy.TermCollection]$DestTermSetTerms = $DestTermSet.GetAllTerms()
        $DestCtx.Load($DestTermSetTerms)
        ExecuteQueryWithRetry $DestCtx

        if($SrcTermSetTerms.count -ne $DestTermSetTerms.Count)
        {
            [int]$missingCount = $SrcTermSetTerms.count - $DestTermSetTerms.Count
            Write-Host "There are '$($missingCount)' terms missing from Destination TermSet '$($_.Name)'" -ForegroundColor Red
            [string[]]$MissingRootTermNames = @()
            $missingids = $SrcTermSetTerms.id | ?{$_ -notin $DestTermSetTerms.id}
            foreach($missingid in $missingids)
            {
                [Microsoft.SharePoint.Client.Taxonomy.Term]$missingterm = $_.GetTerm("$missingid")
                $SrcCtx.Load($missingterm)
                ExecuteQueryWithRetry $srcCtx
                Write-Host "This is the missing Term: '$($missingterm.Name)'" -ForegroundColor Red
                $missingrootTermName = $missingterm.PathOfTerm.Split(";")[0]

                # Make sure we don't add duplicate root terms
                if($missingrootTermName -notin $MissingRootTermNames)
                {
                    $MissingRootTermNames += $MissingRootTermName
                }
            }
            Write-Host "These are the missing root terms: '$($missingroottermnames)'" -ForegroundColor Red
            foreach($rootTermName in $MissingRootTermNames)
            { 
                Write-Host "Getting Root Term: '$($rootTermName)'" -ForegroundColor Magenta
                [Microsoft.SharePoint.Client.Taxonomy.Term]$SrcRootTerm = $_.Terms | ?{$_.Name -eq $rootTermName}
                $SrcCtx.Load($SrcRootTerm)
                ExecuteQueryWithRetry $SrcCtx
                WalkSourceTerm -term $SrcRootTerm -termset $DestTermSet -termgroup $DestGroup
            }
        }
        else
        {
            Write-Host "Source Termset Total Term Count = Destination Termset Total Term Count of '$($DestTermSetTerms.Count)' Terms." -ForegroundColor Green
            Write-Host "Skipping migrating termset" -ForegroundColor Cyan
        }
    }
    $SrcCtx.Dispose()
    $DestCtx.Dispose()
}

Write-Host "Done Migrating Term Store!!!" -ForegroundColor Green
write-host "Migration took '$($stopwatch.Elapsed)'" -ForegroundColor Yellow
#endregion